import type { Sequelize } from "sequelize"
import { initUser } from "./user.model"
import { initBrokerCredential } from "./brokerCredential.model"
import { initBrokerAccount } from "./brokerAccount.model"
import { initPosition } from "./position.model"
import { initTrade } from "./trade.model"
import { initCopyTradeSetting } from "./copyTradeSetting.model"
import { initCopyTradeLog } from "./copyTradeLog.model"
import { initSymbol } from "./symbol.model"
import { initNotification } from "./notification.model"
import { initLog } from "./log.model"
import { initRiskSetting } from "./riskSetting.model"

export const initializeModels = (sequelize: Sequelize) => {
  // Initialize models
  const UserModel = initUser(sequelize)
  const BrokerCredentialModel = initBrokerCredential(sequelize)
  const BrokerAccountModel = initBrokerAccount(sequelize)
  const PositionModel = initPosition(sequelize)
  const TradeModel = initTrade(sequelize)
  const CopyTradeSettingModel = initCopyTradeSetting(sequelize)
  const CopyTradeLogModel = initCopyTradeLog(sequelize)
  const SymbolModel = initSymbol(sequelize)
  const NotificationModel = initNotification(sequelize)
  const LogModel = initLog(sequelize)
  const RiskSettingModel = initRiskSetting(sequelize)

  // Define associations
  BrokerCredentialModel.hasMany(BrokerAccountModel, { foreignKey: "brokerId" })
  BrokerAccountModel.belongsTo(BrokerCredentialModel, { foreignKey: "brokerId" })

  BrokerAccountModel.hasMany(PositionModel, { foreignKey: "brokerAccountId" })
  PositionModel.belongsTo(BrokerAccountModel, { foreignKey: "brokerAccountId" })

  BrokerAccountModel.hasMany(TradeModel, { foreignKey: "brokerAccountId" })
  TradeModel.belongsTo(BrokerAccountModel, { foreignKey: "brokerAccountId" })

  TradeModel.hasMany(CopyTradeLogModel, { foreignKey: "sourceTradeId" })
  CopyTradeLogModel.belongsTo(TradeModel, { foreignKey: "sourceTradeId", as: "sourceTrade" })
  CopyTradeLogModel.belongsTo(TradeModel, { foreignKey: "targetTradeId", as: "targetTrade" })

  return {
    User: UserModel,
    BrokerCredential: BrokerCredentialModel,
    BrokerAccount: BrokerAccountModel,
    Position: PositionModel,
    Trade: TradeModel,
    CopyTradeSetting: CopyTradeSettingModel,
    CopyTradeLog: CopyTradeLogModel,
    Symbol: SymbolModel,
    Notification: NotificationModel,
    Log: LogModel,
    RiskSetting: RiskSettingModel,
  }
}
