import express from "express"
import cors from "cors"
import dotenv from "dotenv"
import helmet from "helmet"
import morgan from "morgan"
import { Sequelize } from "sequelize"
import authRoutes from "./routes/auth.routes"
import brokerRoutes from "./routes/broker.routes"
import tradeRoutes from "./routes/trade.routes"
import copyTradeRoutes from "./routes/copyTrade.routes"
import settingsRoutes from "./routes/settings.routes"
import symbolRoutes from "./routes/symbol.routes"
import notificationRoutes from "./routes/notification.routes"
import logRoutes from "./routes/log.routes"
import { authenticateJWT } from "./middleware/auth.middleware"
import { initializeModels } from "./models"

// Load environment variables
dotenv.config()

// Initialize Express app
const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(helmet())
app.use(morgan("dev"))
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Database connection
const sequelize = new Sequelize(
  process.env.DB_NAME || "tradfclx_platform",
  process.env.DB_USER || "tradfclx_admin",
  process.env.DB_PASSWORD || "Abdulqaudri@123456789",
  {
    host: process.env.DB_HOST || "localhost",
    port: Number.parseInt(process.env.DB_PORT || "3306"),
    dialect: "mysql",
    logging: process.env.NODE_ENV === "development" ? console.log : false,
    pool: {
      max: 5,
      min: 0,
      acquire: 30000,
      idle: 10000,
    },
  },
)

// Initialize models
initializeModels(sequelize)

// Public routes
app.use("/api/auth", authRoutes)

// Protected routes
app.use("/api/brokers", authenticateJWT, brokerRoutes)
app.use("/api/trades", authenticateJWT, tradeRoutes)
app.use("/api/copy-trading", authenticateJWT, copyTradeRoutes)
app.use("/api/settings", authenticateJWT, settingsRoutes)
app.use("/api/symbols", authenticateJWT, symbolRoutes)
app.use("/api/notifications", authenticateJWT, notificationRoutes)
app.use("/api/logs", authenticateJWT, logRoutes)

// Error handling middleware
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  console.error(err.stack)
  res.status(500).json({
    success: false,
    message: "Internal Server Error",
    error: process.env.NODE_ENV === "development" ? err.message : undefined,
  })
})

// Start server
sequelize
  .sync({ alter: process.env.NODE_ENV === "development" })
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
    })
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err)
  })

export default app
