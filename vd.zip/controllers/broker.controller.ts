import type { Request, Response } from "express"
import { BrokerCredential, BrokerType, BrokerConnectionStatus } from "../models/brokerCredential.model"
import { BrokerAccount } from "../models/brokerAccount.model"
import { Position } from "../models/position.model"
import { Log } from "../models/log.model"
import { Notification } from "../models/notification.model"
import {
  authenticateTastytrade,
  fetchTastytradeAccounts,
  fetchTastytradeBalance,
  fetchTastytradePositions,
  checkTastytradeHealth,
} from "../services/tastytrade.service"
import {
  exchangeSchwabAuthCode,
  fetchSchwabAccounts,
  fetchSchwabBalance,
  fetchSchwabPositions,
  checkSchwabHealth,
} from "../services/schwab.service"
import { sendBrokerStatusUpdates } from "../services/websocket.service"

// Connect broker account
export const connectBroker = async (req: Request, res: Response) => {
  try {
    const { name, broker_type, username, password, client_id, client_secret, redirect_uri } = req.body

    // Validate required fields
    if (!name || !broker_type) {
      return res.status(400).json({ success: false, message: "Name and broker type are required" })
    }

    // Validate broker-specific fields
    if (broker_type === BrokerType.TASTYTRADE && (!username || !password)) {
      return res.status(400).json({ success: false, message: "Username and password are required for Tastytrade" })
    }

    if (broker_type === BrokerType.SCHWAB && (!client_id || !client_secret || !redirect_uri)) {
      return res.status(400).json({
        success: false,
        message: "Client ID, client secret, and redirect URI are required for Schwab",
      })
    }

    // Create broker credentials
    const brokerCredential = await BrokerCredential.create({
      name,
      brokerType: broker_type,
      username,
      password, // Note: In a production app, you'd want to encrypt this
      clientId: client_id,
      clientSecret: client_secret,
      redirectUri: redirect_uri,
      isActive: true,
      connectionStatus: BrokerConnectionStatus.CONNECTING,
    })

    // Authenticate with broker
    if (broker_type === BrokerType.TASTYTRADE) {
      const authResult = await authenticateTastytrade(username, password)

      if (!authResult.success) {
        await brokerCredential.update({
          connectionStatus: BrokerConnectionStatus.ERROR,
          connectionError: authResult.message,
        })

        return res.status(400).json({ success: false, message: authResult.message })
      }

      // Update broker with session token
      const expiryDate = new Date()
      expiryDate.setDate(expiryDate.getDate() + 7) // Tastytrade tokens typically last 7 days

      await brokerCredential.update({
        sessionToken: authResult.data.session_token,
        expiry: expiryDate,
        connectionStatus: BrokerConnectionStatus.CONNECTED,
      })

      // Fetch accounts
      const accountsResult = await fetchTastytradeAccounts(authResult.data.session_token)

      if (accountsResult.success && accountsResult.data.items) {
        // Create broker accounts
        for (const item of accountsResult.data.items) {
          const account = item.account
          if (!account.is_closed) {
            // Fetch balance for this account
            const balanceResult = await fetchTastytradeBalance(authResult.data.session_token, account.account_number)

            let balance = 0
            let buyingPower = 0

            if (balanceResult.success) {
              balance = balanceResult.data.net_liquidating_value || 0
              buyingPower = balanceResult.data.margin_buying_power || 0
            }

            await BrokerAccount.create({
              brokerId: brokerCredential.id,
              accountId: account.account_number,
              accountName: account.nickname || `Tastytrade Account ${account.account_number}`,
              accountType: account.account_type_name,
              balance,
              buyingPower,
              isActive: true,
            })
          }
        }
      }

      // Create notification
      await Notification.create({
        type: "success",
        title: "Broker Connected",
        message: `Successfully connected to Tastytrade account: ${name}`,
        read: false,
      })

      // Log the connection
      await Log.create({
        level: "info",
        message: `Tastytrade broker connected: ${name}`,
        source: "broker",
        userId: req.user?.id,
      })

      // Send broker status update via WebSocket
      const brokers = await BrokerCredential.findAll()
      sendBrokerStatusUpdates(
        brokers.map((b) => ({
          id: b.id,
          name: b.name,
          status: b.connectionStatus,
        })),
      )

      return res.status(200).json({
        success: true,
        message: "Tastytrade broker connected successfully",
        data: brokerCredential,
      })
    } else if (broker_type === BrokerType.SCHWAB) {
      // For Schwab, we just return the credentials and let the frontend handle the OAuth flow
      return res.status(200).json({
        success: true,
        message: "Schwab broker credentials created. Please complete OAuth flow.",
        data: brokerCredential,
        credentials: {
          id: brokerCredential.id,
          name: brokerCredential.name,
          broker_type: brokerCredential.brokerType,
          client_id: brokerCredential.clientId,
          redirect_uri: brokerCredential.redirectUri,
        },
      })
    }

    return res.status(400).json({ success: false, message: "Unsupported broker type" })
  } catch (error: any) {
    console.error("Error connecting broker:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while connecting the broker",
      error: error.message,
    })
  }
}

// Complete Schwab OAuth flow
export const completeSchwabOAuth = async (req: Request, res: Response) => {
  try {
    const { credentials, code } = req.body

    if (!credentials || !credentials.id || !code) {
      return res.status(400).json({ success: false, message: "Credentials and authorization code are required" })
    }

    // Find the broker credential
    const brokerCredential = await BrokerCredential.findByPk(credentials.id)

    if (!brokerCredential) {
      return res.status(404).json({ success: false, message: "Broker credential not found" })
    }

    // Exchange code for token
    const tokenResult = await exchangeSchwabAuthCode(
      code,
      brokerCredential.clientId || "",
      brokerCredential.clientSecret || "",
      brokerCredential.redirectUri || "",
    )

    if (!tokenResult.success) {
      await brokerCredential.update({
        connectionStatus: BrokerConnectionStatus.ERROR,
        connectionError: tokenResult.message,
      })

      return res.status(400).json({ success: false, message: tokenResult.message })
    }

    // Calculate token expiry
    const expiryDate = new Date()
    expiryDate.setSeconds(expiryDate.getSeconds() + tokenResult.data.expires_in)

    // Update broker with access token
    await brokerCredential.update({
      sessionToken: tokenResult.data.access_token,
      expiry: expiryDate,
      connectionStatus: BrokerConnectionStatus.CONNECTED,
    })

    // Fetch accounts
    const accountsResult = await fetchSchwabAccounts(tokenResult.data.access_token)

    if (accountsResult.success && accountsResult.data.accounts) {
      // Create broker accounts
      for (const account of accountsResult.data.accounts) {
        // Fetch balance for this account
        const balanceResult = await fetchSchwabBalance(tokenResult.data.access_token, account.accountId)

        let balance = 0
        let buyingPower = 0

        if (balanceResult.success) {
          balance = balanceResult.data.accountValue || 0
          buyingPower = balanceResult.data.buyingPower || 0
        }

        await BrokerAccount.create({
          brokerId: brokerCredential.id,
          accountId: account.accountId,
          accountName: account.nickname || `Schwab Account ${account.accountId}`,
          accountType: account.accountType,
          balance,
          buyingPower,
          isActive: true,
        })
      }
    }

    // Create notification
    await Notification.create({
      type: "success",
      title: "Broker Connected",
      message: `Successfully connected to Schwab account: ${brokerCredential.name}`,
      read: false,
    })

    // Log the connection
    await Log.create({
      level: "info",
      message: `Schwab broker connected: ${brokerCredential.name}`,
      source: "broker",
      userId: req.user?.id,
    })

    // Send broker status update via WebSocket
    const brokers = await BrokerCredential.findAll()
    sendBrokerStatusUpdates(
      brokers.map((b) => ({
        id: b.id,
        name: b.name,
        status: b.connectionStatus,
      })),
    )

    return res.status(200).json({
      success: true,
      message: "Schwab broker connected successfully",
      data: brokerCredential,
    })
  } catch (error: any) {
    console.error("Error completing Schwab OAuth:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while connecting to Schwab",
      error: error.message,
    })
  }
}

// Get all broker accounts
export const getBrokerAccounts = async (req: Request, res: Response) => {
  try {
    const accounts = await BrokerAccount.findAll({
      include: [
        {
          model: BrokerCredential,
          attributes: ["id", "name", "brokerType", "connectionStatus"],
        },
      ],
    })

    return res.status(200).json({
      success: true,
      data: accounts,
    })
  } catch (error: any) {
    console.error("Error fetching broker accounts:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while fetching broker accounts",
      error: error.message,
    })
  }
}

// Get broker account balance
export const getBrokerBalance = async (req: Request, res: Response) => {
  try {
    const { accountId } = req.params

    // Find the broker account
    const account = await BrokerAccount.findByPk(accountId, {
      include: [BrokerCredential],
    })

    if (!account) {
      return res.status(404).json({ success: false, message: "Broker account not found" })
    }

    // Get the broker credential
    const brokerCredential = account.BrokerCredential

    if (!brokerCredential || !brokerCredential.sessionToken) {
      return res.status(400).json({ success: false, message: "Broker not properly connected" })
    }

    // Fetch balance from broker API
    let balanceResult

    if (brokerCredential.brokerType === BrokerType.TASTYTRADE) {
      balanceResult = await fetchTastytradeBalance(brokerCredential.sessionToken, account.accountId)
    } else if (brokerCredential.brokerType === BrokerType.SCHWAB) {
      balanceResult = await fetchSchwabBalance(brokerCredential.sessionToken, account.accountId)
    } else {
      return res.status(400).json({ success: false, message: "Unsupported broker type" })
    }

    if (!balanceResult.success) {
      return res.status(400).json({ success: false, message: balanceResult.message })
    }

    // Update account balance in database
    if (brokerCredential.brokerType === BrokerType.TASTYTRADE) {
      await account.update({
        balance: balanceResult.data.net_liquidating_value || 0,
        buyingPower: balanceResult.data.margin_buying_power || 0,
      })

      return res.status(200).json({
        success: true,
        data: {
          total_equity: balanceResult.data.net_liquidating_value || 0,
          cash_balance: balanceResult.data.cash_balance || 0,
          buying_power: balanceResult.data.margin_buying_power || 0,
          day_trading_buying_power: balanceResult.data.day_trade_buying_power || 0,
          margin_maintenance: balanceResult.data.maintenance_requirement || 0,
          account_value: balanceResult.data.net_liquidating_value || 0,
        },
      })
    } else if (brokerCredential.brokerType === BrokerType.SCHWAB) {
      await account.update({
        balance: balanceResult.data.accountValue || 0,
        buyingPower: balanceResult.data.buyingPower || 0,
      })

      return res.status(200).json({
        success: true,
        data: {
          total_equity: balanceResult.data.accountValue || 0,
          cash_balance: balanceResult.data.cashBalance || 0,
          buying_power: balanceResult.data.buyingPower || 0,
          day_trading_buying_power: balanceResult.data.dayTradingBuyingPower || 0,
          margin_maintenance: balanceResult.data.marginRequirement || 0,
          account_value: balanceResult.data.accountValue || 0,
        },
      })
    }

    return res.status(400).json({ success: false, message: "Unsupported broker type" })
  } catch (error: any) {
    console.error("Error fetching broker balance:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while fetching broker balance",
      error: error.message,
    })
  }
}

// Get positions for a broker account
export const getPositions = async (req: Request, res: Response) => {
  try {
    const { accountId } = req.params

    // Find the broker account
    const account = await BrokerAccount.findByPk(accountId, {
      include: [BrokerCredential],
    })

    if (!account) {
      return res.status(404).json({ success: false, message: "Broker account not found" })
    }

    // Get the broker credential
    const brokerCredential = account.BrokerCredential

    if (!brokerCredential || !brokerCredential.sessionToken) {
      return res.status(400).json({ success: false, message: "Broker not properly connected" })
    }

    // Fetch positions from broker API
    let positionsResult

    if (brokerCredential.brokerType === BrokerType.TASTYTRADE) {
      positionsResult = await fetchTastytradePositions(brokerCredential.sessionToken, account.accountId)
    } else if (brokerCredential.brokerType === BrokerType.SCHWAB) {
      positionsResult = await fetchSchwabPositions(brokerCredential.sessionToken, account.accountId)
    } else {
      return res.status(400).json({ success: false, message: "Unsupported broker type" })
    }

    if (!positionsResult.success) {
      return res.status(400).json({ success: false, message: positionsResult.message })
    }

    // Process positions and update database
    const positions: Position[] = []

    // Clear existing positions for this account
    await Position.destroy({ where: { brokerAccountId: account.id } })

    // Process based on broker type
    if (brokerCredential.brokerType === BrokerType.TASTYTRADE) {
      for (const item of positionsResult.data.items) {
        const position = item.position

        // Determine if it's an option
        const isOption = position.instrument_type === "Equity Option"

        // Create position record
        const newPosition = await Position.create({
          brokerAccountId: account.id,
          symbol: position.symbol,
          quantity: position.quantity,
          averagePrice: position.average_open_price,
          currentPrice: position.mark_price || position.average_open_price,
          unrealizedPnl: position.unrealized_profit_loss || 0,
          unrealizedPnlPercent: position.unrealized_profit_loss_percent || 0,
          value: position.mark_value || 0,
          type: isOption ? "option" : "stock",
          expirationDate: isOption ? position.expiration_date : undefined,
          strikePrice: isOption ? position.strike_price : undefined,
          optionType: isOption ? (position.option_type?.toLowerCase() as "call" | "put") : undefined,
        })

        positions.push(newPosition)
      }
    } else if (brokerCredential.brokerType === BrokerType.SCHWAB) {
      for (const position of positionsResult.data.positions) {
        // Determine if it's an option
        const isOption = position.assetType === "OPTION"

        // Create position record
        const newPosition = await Position.create({
          brokerAccountId: account.id,
          symbol: position.symbol,
          quantity: position.quantity,
          averagePrice: position.averageCost,
          currentPrice: position.marketPrice,
          unrealizedPnl: position.unrealizedPnL || 0,
          unrealizedPnlPercent: (position.unrealizedPnL / (position.averageCost * position.quantity)) * 100 || 0,
          value: position.marketValue || 0,
          type: isOption ? "option" : "stock",
          expirationDate: isOption ? position.expirationDate : undefined,
          strikePrice: isOption ? position.strikePrice : undefined,
          optionType: isOption ? (position.optionType.toLowerCase() as "call" | "put") : undefined,
        })

        positions.push(newPosition)
      }
    }

    return res.status(200).json({
      success: true,
      data: positions,
    })
  } catch (error: any) {
    console.error("Error fetching positions:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while fetching positions",
      error: error.message,
    })
  }
}

// Check broker health
export const checkBrokerHealth = async (req: Request, res: Response) => {
  try {
    const { brokerId } = req.params

    // Find the broker credential
    const brokerCredential = await BrokerCredential.findByPk(brokerId)

    if (!brokerCredential) {
      return res.status(404).json({ success: false, message: "Broker credential not found" })
    }

    // Check health based on broker type
    let healthResult

    if (brokerCredential.brokerType === BrokerType.TASTYTRADE) {
      healthResult = await checkTastytradeHealth(brokerCredential.id)
    } else if (brokerCredential.brokerType === BrokerType.SCHWAB) {
      healthResult = await checkSchwabHealth(brokerCredential.id)
    } else {
      return res.status(400).json({ success: false, message: "Unsupported broker type" })
    }

    // Send broker status update via WebSocket
    const brokers = await BrokerCredential.findAll()
    sendBrokerStatusUpdates(
      brokers.map((b) => ({
        id: b.id,
        name: b.name,
        status: b.connectionStatus,
      })),
    )

    return res.status(200).json({
      success: true,
      data: healthResult,
    })
  } catch (error: any) {
    console.error("Error checking broker health:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while checking broker health",
      error: error.message,
    })
  }
}

// Disconnect broker
export const disconnectBroker = async (req: Request, res: Response) => {
  try {
    const { brokerId } = req.params

    // Find the broker credential
    const brokerCredential = await BrokerCredential.findByPk(brokerId)

    if (!brokerCredential) {
      return res.status(404).json({ success: false, message: "Broker credential not found" })
    }

    // Find all accounts for this broker
    const accounts = await BrokerAccount.findAll({ where: { brokerId } })

    // Delete all positions for these accounts
    for (const account of accounts) {
      await Position.destroy({ where: { brokerAccountId: account.id } })
    }

    // Delete all accounts
    await BrokerAccount.destroy({ where: { brokerId } })

    // Delete the broker credential
    await brokerCredential.destroy()

    // Create notification
    await Notification.create({
      type: "info",
      title: "Broker Disconnected",
      message: `Broker ${brokerCredential.name} has been disconnected`,
      read: false,
    })

    // Log the disconnection
    await Log.create({
      level: "info",
      message: `Broker disconnected: ${brokerCredential.name}`,
      source: "broker",
      userId: req.user?.id,
    })

    // Send broker status update via WebSocket
    const brokers = await BrokerCredential.findAll()
    sendBrokerStatusUpdates(
      brokers.map((b) => ({
        id: b.id,
        name: b.name,
        status: b.connectionStatus,
      })),
    )

    return res.status(200).json({
      success: true,
      message: "Broker disconnected successfully",
    })
  } catch (error: any) {
    console.error("Error disconnecting broker:", error)
    return res.status(500).json({
      success: false,
      message: "An error occurred while disconnecting the broker",
      error: error.message,
    })
  }
}
