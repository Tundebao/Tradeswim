"use client"

import { useState } from "react"
import AdminLayout from "@/components/layout/AdminLayout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import CopyTradeSettings from "@/components/admin/CopyTradeSettings"
import CopyTradeStatus from "@/components/admin/CopyTradeStatus"
import RiskSettings from "@/components/admin/RiskSettings"

const CopySettings = () => {
  const [activeTab, setActiveTab] = useState("status")

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Copy Trading</h1>
          <p className="text-muted-foreground">Manage copy trading settings and monitor status</p>
        </div>

        <Tabs defaultValue="status" value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="status">Status</TabsTrigger>
            <TabsTrigger value="settings">Copy Settings</TabsTrigger>
            <TabsTrigger value="risk">Risk Management</TabsTrigger>
          </TabsList>

          <TabsContent value="status" className="space-y-6">
            <CopyTradeStatus />
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <CopyTradeSettings />
          </TabsContent>

          <TabsContent value="risk" className="space-y-6">
            <RiskSettings />
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  )
}

export default CopySettings
