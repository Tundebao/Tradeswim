"use client"

import type React from "react"
import { createContext, useState, useEffect, useContext } from "react"
import { useNavigate } from "react-router-dom"
import * as authService from "../services/auth.service"
import { connectWebSocket, disconnectWebSocket } from "../services/websocket.service"

interface AuthContextType {
  user: authService.User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => Promise<void>
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: true,
  login: async () => {},
  logout: async () => {},
  changePassword: async () => {},
})

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<authService.User | null>(null)
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const navigate = useNavigate()

  useEffect(() => {
    const checkAuthStatus = async () => {
      try {
        if (authService.isAuthenticated()) {
          const userData = await authService.checkAuth()
          setUser(userData)
          setIsAuthenticated(true)

          // Connect WebSocket
          connectWebSocket()
        }
      } catch (error) {
        console.error("Auth check error:", error)
        // Clear invalid token
        localStorage.removeItem("token")
      } finally {
        setIsLoading(false)
      }
    }

    checkAuthStatus()

    return () => {
      // Disconnect WebSocket on unmount
      disconnectWebSocket()
    }
  }, [])

  const login = async (username: string, password: string) => {
    try {
      setIsLoading(true)
      const response = await authService.login({ username, password })
      setUser(response.user)
      setIsAuthenticated(true)

      // Connect WebSocket
      connectWebSocket()

      // Navigate to dashboard
      navigate("/dashboard")
    } catch (error) {
      console.error("Login error:", error)
      throw error
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async () => {
    try {
      await authService.logout()
    } catch (error) {
      console.error("Logout error:", error)
    } finally {
      // Disconnect WebSocket
      disconnectWebSocket()

      setUser(null)
      setIsAuthenticated(false)
      navigate("/login")
    }
  }

  const changePassword = async (currentPassword: string, newPassword: string) => {
    try {
      await authService.changePassword(currentPassword, newPassword)
    } catch (error) {
      console.error("Change password error:", error)
      throw error
    }
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated,
        isLoading,
        login,
        logout,
        changePassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => useContext(AuthContext)
