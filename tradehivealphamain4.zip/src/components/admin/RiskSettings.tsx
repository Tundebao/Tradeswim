"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { AlertCircle, Check, Loader2, Shield } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import * as riskService from "@/services/risk.service"

const RiskSettings = () => {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [settings, setSettings] = useState<riskService.RiskSettings>({
    maxTradeSizePercent: 5,
    maxDailyLossPercent: 3,
    maxPositionsPerSymbol: 3,
    maxTotalPositions: 20,
    stopLossEnabled: false,
    stopLossPercent: 10,
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  useEffect(() => {
    const loadSettings = async () => {
      try {
        setIsLoading(true)
        const data = await riskService.getRiskSettings()
        setSettings(data)
      } catch (error) {
        console.error("Failed to load risk settings:", error)
        toast({
          title: "Error",
          description: "Failed to load settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadSettings()
  }, [toast])

  const handleSwitchChange = (field: keyof riskService.RiskSettings, checked: boolean) => {
    setSettings((prev) => ({
      ...prev,
      [field]: checked,
    }))
  }

  const handleInputChange = (field: keyof riskService.RiskSettings, value: string) => {
    const numValue = Number.parseFloat(value)
    if (!isNaN(numValue)) {
      setSettings((prev) => ({
        ...prev,
        [field]: numValue,
      }))
    }
  }

  const handleSaveSettings = async () => {
    try {
      setError("")
      setSuccess("")
      setIsSaving(true)

      await riskService.updateRiskSettings(settings)

      setSuccess("Risk settings updated successfully")
      toast({
        title: "Success",
        description: "Risk settings updated successfully",
      })
    } catch (error) {
      console.error("Failed to update risk settings:", error)
      setError("Failed to update settings. Please try again.")
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-60">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center space-x-2">
          <Shield className="h-5 w-5 text-primary" />
          <div>
            <CardTitle>Risk Management Settings</CardTitle>
            <CardDescription>Configure risk controls and limits for trading</CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 border-green-200 text-green-800">
            <Check className="h-4 w-4" />
            <AlertTitle>Success</AlertTitle>
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-6">
          <h3 className="text-lg font-medium">Position Limits</h3>

          <div className="space-y-2">
            <Label htmlFor="maxTradeSizePercent">Maximum Trade Size (%)</Label>
            <Input
              id="maxTradeSizePercent"
              type="number"
              min="0"
              step="0.1"
              value={settings.maxTradeSizePercent}
              onChange={(e) => handleInputChange("maxTradeSizePercent", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Maximum percentage of account balance allowed for any single trade
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="maxPositionsPerSymbol">Maximum Positions Per Symbol</Label>
            <Input
              id="maxPositionsPerSymbol"
              type="number"
              min="1"
              step="1"
              value={settings.maxPositionsPerSymbol}
              onChange={(e) => handleInputChange("maxPositionsPerSymbol", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">Maximum number of positions allowed for a single symbol</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="maxTotalPositions">Maximum Total Positions</Label>
            <Input
              id="maxTotalPositions"
              type="number"
              min="1"
              step="1"
              value={settings.maxTotalPositions}
              onChange={(e) => handleInputChange("maxTotalPositions", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Maximum total number of positions allowed across all accounts
            </p>
          </div>
        </div>

        <Separator />

        <div className="space-y-6">
          <h3 className="text-lg font-medium">Loss Protection</h3>

          <div className="space-y-2">
            <Label htmlFor="maxDailyLossPercent">Maximum Daily Loss (%)</Label>
            <Input
              id="maxDailyLossPercent"
              type="number"
              min="0"
              step="0.1"
              value={settings.maxDailyLossPercent}
              onChange={(e) => handleInputChange("maxDailyLossPercent", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Maximum percentage of account balance that can be lost in a single day
            </p>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="stopLossEnabled">Automatic Stop Loss</Label>
              <p className="text-sm text-muted-foreground">
                Automatically close positions when they reach the specified loss percentage
              </p>
            </div>
            <Switch
              id="stopLossEnabled"
              checked={settings.stopLossEnabled}
              onCheckedChange={(checked) => handleSwitchChange("stopLossEnabled", checked)}
            />
          </div>

          {settings.stopLossEnabled && (
            <div className="space-y-2">
              <Label htmlFor="stopLossPercent">Stop Loss Percentage (%)</Label>
              <Input
                id="stopLossPercent"
                type="number"
                min="0"
                step="0.1"
                value={settings.stopLossPercent}
                onChange={(e) => handleInputChange("stopLossPercent", e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                Close positions when they lose this percentage of their value
              </p>
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-end border-t pt-6">
        <Button onClick={handleSaveSettings} disabled={isSaving}>
          {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSaving ? "Saving..." : "Save Settings"}
        </Button>
      </CardFooter>
    </Card>
  )
}

export default RiskSettings
