"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AlertCircle, Check, Copy, Loader2, Power, PowerOff, RefreshCw } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import * as copyTradeService from "@/services/copyTrade.service"
import { formatDateTime } from "@/utils/dateUtils"

const CopyTradeStatus = () => {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [isToggling, setIsToggling] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [status, setStatus] = useState<copyTradeService.CopyTradeStatus | null>(null)

  useEffect(() => {
    loadStatus()
  }, [])

  const loadStatus = async () => {
    try {
      setIsLoading(true)
      const data = await copyTradeService.getCopyTradingStatus()
      setStatus(data)
    } catch (error) {
      console.error("Failed to load copy trading status:", error)
      toast({
        title: "Error",
        description: "Failed to load copy trading status. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleToggleCopyTrading = async () => {
    if (!status) return

    try {
      setIsToggling(true)
      await copyTradeService.toggleCopyTrading(!status.isEnabled)

      // Update local state
      setStatus((prev) => (prev ? { ...prev, isEnabled: !prev.isEnabled } : null))

      toast({
        title: "Success",
        description: `Copy trading ${!status.isEnabled ? "enabled" : "disabled"} successfully`,
      })
    } catch (error) {
      console.error("Failed to toggle copy trading:", error)
      toast({
        title: "Error",
        description: "Failed to update copy trading status",
        variant: "destructive",
      })
    } finally {
      setIsToggling(false)
    }
  }

  const handleRefresh = async () => {
    try {
      setIsRefreshing(true)
      await loadStatus()
      toast({
        title: "Success",
        description: "Copy trading status refreshed",
      })
    } catch (error) {
      console.error("Failed to refresh copy trading status:", error)
    } finally {
      setIsRefreshing(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-60">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between space-y-0">
        <div>
          <CardTitle>Copy Trading Status</CardTitle>
          <CardDescription>Current status of the copy trading system</CardDescription>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing}>
            {isRefreshing ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
            <span className="ml-2">Refresh</span>
          </Button>
          <Button
            variant={status?.isEnabled ? "destructive" : "default"}
            size="sm"
            onClick={handleToggleCopyTrading}
            disabled={isToggling}
          >
            {isToggling ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : status?.isEnabled ? (
              <PowerOff className="h-4 w-4 mr-2" />
            ) : (
              <Power className="h-4 w-4 mr-2" />
            )}
            {status?.isEnabled ? "Disable" : "Enable"} Copy Trading
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {!status?.masterBroker && (
          <Alert variant="warning">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              No master broker set. Please set a master broker in the Broker Accounts page.
            </AlertDescription>
          </Alert>
        )}

        <div className="grid gap-4 md:grid-cols-3">
          <div className="space-y-2">
            <h3 className="font-medium">Status</h3>
            <Badge variant={status?.isEnabled ? "success" : "secondary"} className="text-xs">
              {status?.isEnabled ? <Check className="h-3 w-3 mr-1" /> : <PowerOff className="h-3 w-3 mr-1" />}
              {status?.isEnabled ? "Enabled" : "Disabled"}
            </Badge>
          </div>

          <div className="space-y-2">
            <h3 className="font-medium">Master Broker</h3>
            {status?.masterBroker ? (
              <div className="text-sm">
                {status.masterBroker.brokerType.toUpperCase()} - {status.masterBroker.accountId}
              </div>
            ) : (
              <div className="text-sm text-muted-foreground">No master broker set</div>
            )}
          </div>

          <div className="space-y-2">
            <h3 className="font-medium">Follower Accounts</h3>
            <div className="text-sm">
              {status?.followerCount} account{status?.followerCount !== 1 ? "s" : ""}
            </div>
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h3 className="font-medium">Recent Copy Trades</h3>
          {status?.recentCopyTrades && status.recentCopyTrades.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Time</TableHead>
                  <TableHead>Symbol</TableHead>
                  <TableHead>From</TableHead>
                  <TableHead>To</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {status.recentCopyTrades.map((trade) => (
                  <TableRow key={trade.id}>
                    <TableCell>{formatDateTime(trade.createdAt)}</TableCell>
                    <TableCell>
                      {trade.sourceTrade?.symbol}{" "}
                      <Badge variant="outline" className="ml-1">
                        {trade.sourceTrade?.side}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {trade.sourceBroker?.brokerType.toUpperCase()} - {trade.sourceBroker?.accountId}
                    </TableCell>
                    <TableCell>
                      {trade.targetBroker?.brokerType.toUpperCase()} - {trade.targetBroker?.accountId}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          trade.status === "completed"
                            ? "success"
                            : trade.status === "failed"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {trade.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 border rounded-md bg-gray-50">
              <Copy className="mx-auto h-8 w-8 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium">No recent copy trades</h3>
              <p className="mt-1 text-xs text-gray-500">Copy trades will appear here when executed</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

export default CopyTradeStatus
