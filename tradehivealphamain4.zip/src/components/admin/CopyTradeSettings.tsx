"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { AlertCircle, Check, Loader2 } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"
import * as settingsService from "@/services/settings.service"

const CopyTradeSettings = () => {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(true)
  const [isSaving, setIsSaving] = useState(false)
  const [settings, setSettings] = useState<settingsService.CopyTradingSettings>({
    copyTradingEnabled: false,
    copyTradeLogic: "mirror",
    copyTradeValue: 100,
    maxTradeSizePercent: 5,
    maxDailyLossPercent: 3,
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  useEffect(() => {
    const loadSettings = async () => {
      try {
        setIsLoading(true)
        const data = await settingsService.getCopyTradingSettings()
        setSettings(data)
      } catch (error) {
        console.error("Failed to load copy trading settings:", error)
        toast({
          title: "Error",
          description: "Failed to load settings. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadSettings()
  }, [toast])

  const handleSwitchChange = (field: keyof settingsService.CopyTradingSettings, checked: boolean) => {
    setSettings((prev) => ({
      ...prev,
      [field]: checked,
    }))
  }

  const handleSelectChange = (field: keyof settingsService.CopyTradingSettings, value: string) => {
    setSettings((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleInputChange = (field: keyof settingsService.CopyTradingSettings, value: string) => {
    const numValue = Number.parseFloat(value)
    if (!isNaN(numValue)) {
      setSettings((prev) => ({
        ...prev,
        [field]: numValue,
      }))
    }
  }

  const handleSaveSettings = async () => {
    try {
      setError("")
      setSuccess("")
      setIsSaving(true)

      await settingsService.updateCopyTradingSettings(settings)

      setSuccess("Copy trading settings updated successfully")
      toast({
        title: "Success",
        description: "Copy trading settings updated successfully",
      })
    } catch (error) {
      console.error("Failed to update copy trading settings:", error)
      setError("Failed to update settings. Please try again.")
      toast({
        title: "Error",
        description: "Failed to update settings",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-60">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Copy Trading Settings</CardTitle>
        <CardDescription>Configure how trades are copied across accounts</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="bg-green-50 border-green-200 text-green-800">
            <Check className="h-4 w-4" />
            <AlertTitle>Success</AlertTitle>
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label htmlFor="copyTradingEnabled">Enable Copy Trading</Label>
            <p className="text-sm text-muted-foreground">
              When enabled, trades from the master account will be copied to follower accounts
            </p>
          </div>
          <Switch
            id="copyTradingEnabled"
            checked={settings.copyTradingEnabled}
            onCheckedChange={(checked) => handleSwitchChange("copyTradingEnabled", checked)}
          />
        </div>

        <Separator />

        <div className="space-y-2">
          <Label htmlFor="copyTradeLogic">Copy Logic</Label>
          <Select
            value={settings.copyTradeLogic}
            onValueChange={(value) => handleSelectChange("copyTradeLogic", value)}
          >
            <SelectTrigger id="copyTradeLogic">
              <SelectValue placeholder="Select copy logic" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="mirror">Mirror Exact Shares</SelectItem>
              <SelectItem value="fixedSize">Fixed Dollar Amount</SelectItem>
              <SelectItem value="percentBalance">Percentage of Balance</SelectItem>
            </SelectContent>
          </Select>
          <p className="text-sm text-muted-foreground">
            {settings.copyTradeLogic === "mirror"
              ? "Copy the exact number of shares/contracts from the master account"
              : settings.copyTradeLogic === "fixedSize"
                ? "Use a fixed dollar amount for each copied trade"
                : "Use a percentage of the follower account's balance for each copied trade"}
          </p>
        </div>

        {settings.copyTradeLogic !== "mirror" && (
          <div className="space-y-2">
            <Label htmlFor="copyTradeValue">
              {settings.copyTradeLogic === "fixedSize" ? "Fixed Amount ($)" : "Percentage of Balance (%)"}
            </Label>
            <Input
              id="copyTradeValue"
              type="number"
              min="0"
              step={settings.copyTradeLogic === "fixedSize" ? "100" : "1"}
              value={settings.copyTradeValue}
              onChange={(e) => handleInputChange("copyTradeValue", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              {settings.copyTradeLogic === "fixedSize"
                ? "Dollar amount to use for each copied trade"
                : "Percentage of follower account balance to use for each copied trade"}
            </p>
          </div>
        )}

        <Separator />

        <div className="space-y-6">
          <h3 className="text-lg font-medium">Risk Controls</h3>

          <div className="space-y-2">
            <Label htmlFor="maxTradeSizePercent">Maximum Trade Size (%)</Label>
            <Input
              id="maxTradeSizePercent"
              type="number"
              min="0"
              step="0.1"
              value={settings.maxTradeSizePercent}
              onChange={(e) => handleInputChange("maxTradeSizePercent", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Maximum percentage of account balance allowed for any single trade
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="maxDailyLossPercent">Maximum Daily Loss (%)</Label>
            <Input
              id="maxDailyLossPercent"
              type="number"
              min="0"
              step="0.1"
              value={settings.maxDailyLossPercent}
              onChange={(e) => handleInputChange("maxDailyLossPercent", e.target.value)}
            />
            <p className="text-sm text-muted-foreground">
              Maximum percentage of account balance that can be lost in a single day
            </p>
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex justify-end border-t pt-6">
        <Button onClick={handleSaveSettings} disabled={isSaving}>
          {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          {isSaving ? "Saving..." : "Save Settings"}
        </Button>
      </CardFooter>
    </Card>
  )
}

export default CopyTradeSettings
