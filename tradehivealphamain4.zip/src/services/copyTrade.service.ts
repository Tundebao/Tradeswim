import api from "./api.service"

export interface CopyTradeStatus {
  isEnabled: boolean
  masterBroker: {
    id: number
    accountId: string
    brokerType: string
  } | null
  followerCount: number
  followers: {
    id: number
    accountId: string
    brokerType: string
  }[]
  recentCopyTrades: {
    id: number
    status: string
    createdAt: string
    sourceBroker: {
      accountId: string
      brokerType: string
    }
    targetBroker: {
      accountId: string
      brokerType: string
    }
    sourceTrade: {
      symbol: string
      side: string
      quantity: number
      price: number
    }
    targetTrade: {
      symbol: string
      side: string
      quantity: number
      price: number
    }
  }[]
}

export interface CopyTradeResult {
  brokerId: number
  success: boolean
  message?: string
  tradeId?: number
}

export const getCopyTradingStatus = async (): Promise<CopyTradeStatus> => {
  const response = await api.get("/copy-trades/status")
  return response.data
}

export const toggleCopyTrading = async (enabled: boolean): Promise<void> => {
  await api.post("/copy-trades/toggle", { enabled })
}

export const getCopyTrades = async (filters?: {
  status?: string
  startDate?: string
  endDate?: string
  limit?: number
  offset?: number
}): Promise<{
  count: number
  copyTrades: any[]
}> => {
  const response = await api.get("/copy-trades", { params: filters })
  return response.data
}

export const manualCopyTrade = async (
  tradeId: number,
): Promise<{
  message: string
  results: CopyTradeResult[]
}> => {
  const response = await api.post(`/copy-trades/${tradeId}`)
  return response.data
}
