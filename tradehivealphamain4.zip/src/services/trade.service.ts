import api from "./api.service"

export interface TradeOrder {
  brokerId: number
  symbol: string
  side: "buy" | "sell"
  quantity: number
  orderType: "market" | "limit" | "stop"
  price?: number
  timeInForce: "day" | "gtc" | "gtc_ext"
  assetType: "stock" | "option" | "etf"
  optionData?: {
    expirationDate: string
    strike: number
    optionType: "call" | "put"
  }
}

export interface Trade {
  id: number
  brokerId: number
  brokerOrderId: string
  symbol: string
  side: "buy" | "sell"
  quantity: number
  price: number
  orderType: "market" | "limit" | "stop"
  timeInForce: "day" | "gtc" | "gtc_ext"
  status: "pending" | "filled" | "cancelled" | "rejected"
  assetType: "stock" | "option" | "etf"
  optionData?: {
    expirationDate: string
    strike: number
    optionType: "call" | "put"
  }
  isManual: boolean
  notes?: string
  createdAt: string
  updatedAt: string
}

export interface Position {
  id: number
  brokerId: number
  symbol: string
  quantity: number
  averagePrice: number
  currentPrice: number
  marketValue: number
  unrealizedPnL: number
  unrealizedPnLPercent: number
  assetType: "stock" | "option" | "etf"
  optionData?: {
    expirationDate: string
    strike: number
    optionType: "call" | "put"
  }
  lastUpdated: string
}

export interface Symbol {
  symbol: string
  name: string
  type: "stock" | "option" | "etf"
}

export const placeOrder = async (order: TradeOrder): Promise<Trade> => {
  const response = await api.post("/trades/execute", order)
  return response.data.trade
}

export const cancelOrder = async (tradeId: number): Promise<void> => {
  await api.post(`/trades/${tradeId}/cancel`)
}

export const updateOrder = async (tradeId: number, updates: Partial<TradeOrder>): Promise<Trade> => {
  const response = await api.put(`/trades/${tradeId}`, updates)
  return response.data.trade
}

export const getTrades = async (filters?: {
  brokerId?: number
  status?: string
  symbol?: string
  limit?: number
  offset?: number
}): Promise<{ count: number; trades: Trade[] }> => {
  const response = await api.get("/trades", { params: filters })
  return response.data
}

export const getPositions = async (brokerId?: number): Promise<Position[]> => {
  const response = await api.get("/trades/positions", { params: { brokerId } })
  return response.data
}

export const closePosition = async (positionId: number): Promise<Trade> => {
  const response = await api.post(`/trades/positions/${positionId}/close`)
  return response.data.trade
}

export const searchSymbol = async (query: string, brokerType: "tastytrade" | "schwab"): Promise<Symbol[]> => {
  const response = await api.get("/trades/symbols/search", { params: { query, brokerType } })
  return response.data
}

export const manualCopyTrade = async (tradeId: number): Promise<void> => {
  await api.post(`/trades/${tradeId}/copy`)
}

export const syncPositions = async (brokerId: number): Promise<Position[]> => {
  const response = await api.post(`/trades/positions/sync/${brokerId}`)
  return response.data.positions
}
