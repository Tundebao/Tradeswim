import api from "./api.service"

export interface LoginCredentials {
  username: string
  password: string
}

export interface User {
  id: number
  username: string
  email: string
  isAdmin: boolean
  lastLogin: string
}

export interface LoginResponse {
  accessToken: string
  user: User
}

export const login = async (credentials: LoginCredentials): Promise<LoginResponse> => {
  const response = await api.post("/auth/login", credentials)

  // Store token in localStorage
  localStorage.setItem("token", response.data.accessToken)

  return response.data
}

export const logout = async (): Promise<void> => {
  try {
    await api.post("/auth/logout")
  } catch (error) {
    console.error("Logout error:", error)
  } finally {
    // Always clear token
    localStorage.removeItem("token")
  }
}

export const checkAuth = async (): Promise<User> => {
  const response = await api.get("/auth/check")
  return response.data
}

export const changePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
  await api.post("/auth/change-password", { currentPassword, newPassword })
}

export const isAuthenticated = (): boolean => {
  return !!localStorage.getItem("token")
}
