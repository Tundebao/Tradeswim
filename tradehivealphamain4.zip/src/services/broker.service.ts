import api from "./api.service"

export interface BrokerAccount {
  id: number
  brokerType: "tastytrade" | "schwab"
  accountId: string
  isConnected: boolean
  isMaster: boolean
  accountBalance: number
  buyingPower: number
  marginAvailable: number
  lastSyncTime: string
}

export interface TastytradeCredentials {
  username: string
  password: string
}

export interface SchwabAuthResponse {
  authUrl: string
}

export const connectTastytrade = async (credentials: TastytradeCredentials): Promise<BrokerAccount> => {
  const response = await api.post("/brokers/tastytrade", credentials)
  return response.data.broker
}

export const initiateSchwabAuth = async (): Promise<SchwabAuthResponse> => {
  const response = await api.get("/brokers/schwab/auth")
  return response.data
}

export const completeSchwabAuth = async (code: string): Promise<BrokerAccount[]> => {
  const response = await api.post("/brokers/schwab/callback", { code })
  return response.data.brokers
}

export const disconnectBroker = async (brokerId: number): Promise<void> => {
  await api.delete(`/brokers/${brokerId}`)
}

export const getBrokers = async (): Promise<BrokerAccount[]> => {
  const response = await api.get("/brokers")
  return response.data
}

export const setMasterBroker = async (brokerId: number): Promise<void> => {
  await api.put(`/brokers/${brokerId}/master`)
}

export const refreshBrokerData = async (brokerId: number): Promise<BrokerAccount> => {
  const response = await api.post(`/brokers/${brokerId}/refresh`)
  return response.data.broker
}
