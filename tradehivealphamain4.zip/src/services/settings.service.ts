import api from "./api.service"

export interface CopyTradingSettings {
  copyTradingEnabled: boolean
  copyTradeLogic: "mirror" | "fixedSize" | "percentBalance"
  copyTradeValue: number
  maxTradeSizePercent: number
  maxDailyLossPercent: number
}

export interface SymbolSettings {
  allowedSymbols: string[]
}

export const getSettings = async (): Promise<Record<string, string>> => {
  const response = await api.get("/settings")
  return response.data
}

export const updateSettings = async (settings: Record<string, string>): Promise<void> => {
  await api.put("/settings", { settings })
}

export const getCopyTradingSettings = async (): Promise<CopyTradingSettings> => {
  const response = await api.get("/settings/copy-trading")
  return response.data
}

export const updateCopyTradingSettings = async (settings: Partial<CopyTradingSettings>): Promise<void> => {
  await api.put("/settings/copy-trading", settings)
}

export const getSymbolSettings = async (): Promise<SymbolSettings> => {
  const response = await api.get("/settings/symbols")
  return response.data
}

export const updateSymbolSettings = async (settings: SymbolSettings): Promise<void> => {
  await api.put("/settings/symbols", settings)
}
