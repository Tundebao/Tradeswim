let socket: WebSocket | null = null
let reconnectTimer: NodeJS.Timeout | null = null
const listeners: Map<string, Set<(data: any) => void>> = new Map()

export const connectWebSocket = (): void => {
  // Close existing connection if any
  if (socket) {
    socket.close()
  }

  // Clear any pending reconnect
  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }

  const token = localStorage.getItem("token")
  if (!token) {
    console.error("No token available for WebSocket connection")
    return
  }

  const protocol = window.location.protocol === "https:" ? "wss:" : "ws:"
  const host = process.env.NODE_ENV === "production" ? window.location.host : "localhost:5000"

  const wsUrl = `${protocol}//${host}/ws?token=${token}`

  socket = new WebSocket(wsUrl)

  socket.onopen = () => {
    console.log("WebSocket connected")

    // Subscribe to default channels
    subscribe("trades")
    subscribe("positions")
    subscribe("notifications")
  }

  socket.onmessage = (event) => {
    try {
      const data = JSON.parse(event.data)

      // Notify listeners based on message type
      const type = data.type || "unknown"
      const typeListeners = listeners.get(type)

      if (typeListeners) {
        typeListeners.forEach((listener) => listener(data))
      }

      // Also notify 'all' listeners
      const allListeners = listeners.get("all")
      if (allListeners) {
        allListeners.forEach((listener) => listener(data))
      }
    } catch (error) {
      console.error("Error processing WebSocket message:", error)
    }
  }

  socket.onclose = (event) => {
    console.log(`WebSocket closed: ${event.code} ${event.reason}`)

    // Attempt to reconnect after delay
    if (!reconnectTimer) {
      reconnectTimer = setTimeout(() => {
        console.log("Attempting to reconnect WebSocket...")
        connectWebSocket()
      }, 5000)
    }
  }

  socket.onerror = (error) => {
    console.error("WebSocket error:", error)
  }
}

export const disconnectWebSocket = (): void => {
  if (socket) {
    socket.close()
    socket = null
  }

  if (reconnectTimer) {
    clearTimeout(reconnectTimer)
    reconnectTimer = null
  }

  // Clear all listeners
  listeners.clear()
}

export const subscribe = (channel: string): void => {
  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(
      JSON.stringify({
        type: "subscribe",
        channel,
      }),
    )
  }
}

export const addListener = (type: string, callback: (data: any) => void): (() => void) => {
  if (!listeners.has(type)) {
    listeners.set(type, new Set())
  }

  const typeListeners = listeners.get(type)!
  typeListeners.add(callback)

  // Return function to remove listener
  return () => {
    typeListeners.delete(callback)
    if (typeListeners.size === 0) {
      listeners.delete(type)
    }
  }
}
