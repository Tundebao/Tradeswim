import api from "./api.service"

export interface RiskSettings {
  maxTradeSizePercent: number
  maxDailyLossPercent: number
  maxPositionsPerSymbol: number
  maxTotalPositions: number
  stopLossEnabled: boolean
  stopLossPercent: number
}

export interface RiskReport {
  totalAccountValue: number
  totalUnrealizedPnL: number
  totalUnrealizedPnLPercent: number
  maxDrawdown: {
    symbol: string | null
    percent: number
  }
  riskBySymbol: Record<
    string,
    {
      totalQuantity: number
      totalValue: number
      unrealizedPnL: number
      unrealizedPnLPercent: number
    }
  >
  riskByBroker: Record<
    string,
    {
      brokerType: string
      accountId: string
      accountBalance: number
      unrealizedPnL: number
      unrealizedPnLPercent: number
      positions: number
    }
  >
}

export const getRiskSettings = async (): Promise<RiskSettings> => {
  const response = await api.get("/risk/settings")
  return response.data
}

export const updateRiskSettings = async (settings: Partial<RiskSettings>): Promise<void> => {
  await api.put("/risk/settings", settings)
}

export const getDailyRiskReport = async (): Promise<RiskReport> => {
  const response = await api.get("/risk/report")
  return response.data
}
