require("dotenv").config()
const express = require("express")
const cors = require("cors")
const http = require("http")
const WebSocket = require("ws")
const path = require("path")
const { sequelize } = require("./config/database")
const authRoutes = require("./routes/auth.routes")
const brokerRoutes = require("./routes/broker.routes")
const tradeRoutes = require("./routes/trade.routes")
const adminRoutes = require("./routes/admin.routes")
const notificationRoutes = require("./routes/notification.routes")
const { verifyToken } = require("./middleware/auth.middleware")

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// Routes
app.use("/api/auth", authRoutes)
app.use("/api/brokers", verifyToken, brokerRoutes)
app.use("/api/trades", verifyToken, tradeRoutes)
app.use("/api/admin", verifyToken, adminRoutes)
app.use("/api/notifications", verifyToken, notificationRoutes)

// Serve static files in production
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../dist")))
  app.get("*", (req, res) => {
    res.sendFile(path.join(__dirname, "../dist/index.html"))
  })
}

// Create HTTP server
const server = http.createServer(app)

// Set up WebSocket server for real-time updates
const wss = new WebSocket.Server({ server })

wss.on("connection", (ws) => {
  console.log("Client connected to WebSocket")

  // Send initial data
  ws.send(JSON.stringify({ type: "connection", status: "connected" }))

  ws.on("message", (message) => {
    const data = JSON.parse(message)
    console.log("Received message:", data)

    // Handle different message types
    if (data.type === "subscribe") {
      ws.accountId = data.accountId
      ws.userId = data.userId
      console.log(`User ${ws.userId} subscribed to account ${ws.accountId}`)
    }
  })

  ws.on("close", () => {
    console.log("Client disconnected from WebSocket")
  })
})

// Broadcast to all connected clients
global.broadcastUpdate = (data) => {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      // Filter broadcasts based on accountId if specified
      if (!data.accountId || client.accountId === data.accountId) {
        client.send(JSON.stringify(data))
      }
    }
  })
}

// Database sync and server start
sequelize
  .sync({ alter: true })
  .then(() => {
    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`)
    })
  })
  .catch((err) => {
    console.error("Failed to sync database:", err)
  })
