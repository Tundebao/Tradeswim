const WebSocket = require("ws")
const jwt = require("jsonwebtoken")
const { User } = require("../models")

// Initialize WebSocket server
const initWebSocket = (server) => {
  const wss = new WebSocket.Server({ server })

  // Store authenticated clients
  const clients = new Map()

  wss.on("connection", async (ws, req) => {
    console.log("WebSocket connection established")

    // Extract token from URL
    const url = new URL(req.url, `http://${req.headers.host}`)
    const token = url.searchParams.get("token")

    if (!token) {
      ws.close(1008, "Authentication required")
      return
    }

    try {
      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET)
      const user = await User.findByPk(decoded.id)

      if (!user) {
        ws.close(1008, "User not found")
        return
      }

      // Store client with user ID
      clients.set(ws, {
        userId: user.id,
        subscriptions: new Set(),
      })

      // Send welcome message
      ws.send(
        JSON.stringify({
          type: "connection",
          message: "Connected to TradeCopy WebSocket",
          userId: user.id,
        }),
      )

      // Set up ping/pong for connection health
      ws.isAlive = true
      ws.on("pong", () => {
        ws.isAlive = true
      })

      // Handle messages
      ws.on("message", (message) => {
        try {
          const data = JSON.parse(message)

          // Handle subscription requests
          if (data.type === "subscribe") {
            const client = clients.get(ws)
            if (client) {
              client.subscriptions.add(data.channel)
              ws.send(
                JSON.stringify({
                  type: "subscribed",
                  channel: data.channel,
                }),
              )
            }
          }
        } catch (error) {
          console.error("Error processing WebSocket message:", error)
        }
      })

      // Handle disconnection
      ws.on("close", () => {
        clients.delete(ws)
        console.log("WebSocket connection closed")
      })
    } catch (error) {
      console.error("WebSocket authentication error:", error)
      ws.close(1008, "Authentication failed")
    }
  })

  // Heartbeat interval to check for dead connections
  const interval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws.isAlive === false) {
        clients.delete(ws)
        return ws.terminate()
      }

      ws.isAlive = false
      ws.ping()
    })
  }, 30000)

  wss.on("close", () => {
    clearInterval(interval)
  })

  // Broadcast function for sending updates to clients
  const broadcast = (data, filter = () => true) => {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        const clientData = clients.get(client)

        if (clientData && filter(clientData)) {
          client.send(JSON.stringify(data))
        }
      }
    })
  }

  // Make broadcast function available globally
  global.broadcastUpdate = (data) => {
    // Filter based on subscriptions and user ID
    const filter = (clientData) => {
      // For user-specific updates
      if (data.userId && data.userId !== clientData.userId) {
        return false
      }

      // For channel-specific updates
      if (data.channel && !clientData.subscriptions.has(data.channel)) {
        return false
      }

      return true
    }

    broadcast(data, filter)
  }

  return wss
}

module.exports = { initWebSocket }
