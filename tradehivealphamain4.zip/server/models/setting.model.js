const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")

const Setting = sequelize.define("Setting", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  key: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  value: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  type: {
    type: DataTypes.ENUM("boolean", "number", "string", "json"),
    allowNull: false,
  },
  category: {
    type: DataTypes.ENUM("trading", "risk", "system", "notification"),
    allowNull: false,
  },
  description: {
    type: DataTypes.TEXT,
  },
})

module.exports = Setting
