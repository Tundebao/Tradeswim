const User = require("./user.model")
const Broker = require("./broker.model")
const Trade = require("./trade.model")
const CopyTrade = require("./copyTrade.model")
const Position = require("./position.model")
const Notification = require("./notification.model")
const Setting = require("./setting.model")
const Symbol = require("./symbol.model")
const ActivityLog = require("./activityLog.model")

module.exports = {
  User,
  Broker,
  Trade,
  CopyTrade,
  Position,
  Notification,
  Setting,
  Symbol,
  ActivityLog,
}
