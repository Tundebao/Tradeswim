const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")
const User = require("./user.model")

const Notification = sequelize.define("Notification", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: "id",
    },
  },
  type: {
    type: DataTypes.ENUM("broker", "trade", "risk", "system"),
    allowNull: false,
  },
  severity: {
    type: DataTypes.ENUM("info", "warning", "error"),
    allowNull: false,
  },
  message: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
  details: {
    type: DataTypes.JSON,
    allowNull: true,
  },
  isRead: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
})

// Associations
Notification.belongsTo(User, { foreignKey: "userId" })

module.exports = Notification
