const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")
const User = require("./user.model")

const Broker = sequelize.define("Broker", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: "id",
    },
  },
  brokerType: {
    type: DataTypes.ENUM("tastytrade", "schwab"),
    allowNull: false,
  },
  accountId: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  accessToken: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  refreshToken: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  tokenExpiry: {
    type: DataTypes.DATE,
    allowNull: true,
  },
  isConnected: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  isMaster: {
    type: DataTypes.BOOLEAN,
    defaultValue: false,
  },
  lastSyncTime: {
    type: DataTypes.DATE,
  },
  accountBalance: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: true,
  },
  buyingPower: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: true,
  },
  marginAvailable: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: true,
  },
})

// Associations
Broker.belongsTo(User, { foreignKey: "userId" })

module.exports = Broker
