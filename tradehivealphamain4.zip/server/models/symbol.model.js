const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")

const Symbol = sequelize.define("Symbol", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  symbol: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  type: {
    type: DataTypes.ENUM("stock", "etf", "option"),
    allowNull: false,
  },
  isAllowed: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
  maxPositionSize: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: true,
  },
  notes: {
    type: DataTypes.TEXT,
  },
})

module.exports = Symbol
