const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")
const User = require("./user.model")
const Broker = require("./broker.model")
const Trade = require("./trade.model")

const CopyTrade = sequelize.define("CopyTrade", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  sourceBrokerId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Broker,
      key: "id",
    },
  },
  targetBrokerId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Broker,
      key: "id",
    },
  },
  sourceTradeId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Trade,
      key: "id",
    },
  },
  targetTradeId: {
    type: DataTypes.INTEGER,
    allowNull: true,
    references: {
      model: Trade,
      key: "id",
    },
  },
  status: {
    type: DataTypes.ENUM("pending", "completed", "failed"),
    defaultValue: "pending",
  },
  errorMessage: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  copyLogic: {
    type: DataTypes.ENUM("exactSize", "fixedSize", "percentBalance"),
    allowNull: false,
  },
  copyValue: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: true,
    comment: "Fixed size amount or percentage value",
  },
})

// Associations
CopyTrade.belongsTo(Broker, { as: "sourceBroker", foreignKey: "sourceBrokerId" })
CopyTrade.belongsTo(Broker, { as: "targetBroker", foreignKey: "targetBrokerId" })
CopyTrade.belongsTo(Trade, { as: "sourceTrade", foreignKey: "sourceTradeId" })
CopyTrade.belongsTo(Trade, { as: "targetTrade", foreignKey: "targetTradeId" })

module.exports = CopyTrade
