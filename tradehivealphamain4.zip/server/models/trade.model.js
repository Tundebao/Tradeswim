const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")
const User = require("./user.model")
const Broker = require("./broker.model")

const Trade = sequelize.define("Trade", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: "id",
    },
  },
  brokerId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Broker,
      key: "id",
    },
  },
  brokerOrderId: {
    type: DataTypes.STRING,
    allowNull: true,
  },
  symbol: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  side: {
    type: DataTypes.ENUM("buy", "sell"),
    allowNull: false,
  },
  quantity: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: false,
  },
  price: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: true,
  },
  orderType: {
    type: DataTypes.ENUM("market", "limit", "stop", "trailingStop"),
    allowNull: false,
  },
  timeInForce: {
    type: DataTypes.ENUM("day", "gtc", "gtcExt"),
    allowNull: false,
  },
  status: {
    type: DataTypes.ENUM("pending", "filled", "cancelled", "rejected", "expired"),
    defaultValue: "pending",
  },
  filledQuantity: {
    type: DataTypes.DECIMAL(15, 6),
    defaultValue: 0,
  },
  filledPrice: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: true,
  },
  assetType: {
    type: DataTypes.ENUM("stock", "etf", "option"),
    allowNull: false,
  },
  optionData: {
    type: DataTypes.JSON,
    allowNull: true,
  },
  isManual: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
  },
  notes: {
    type: DataTypes.TEXT,
  },
})

// Associations
Trade.belongsTo(User, { foreignKey: "userId" })
Trade.belongsTo(Broker, { foreignKey: "brokerId" })

module.exports = Trade
