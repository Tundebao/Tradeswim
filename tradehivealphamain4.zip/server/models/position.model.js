const { DataTypes } = require("sequelize")
const { sequelize } = require("../config/database")
const User = require("./user.model")
const Broker = require("./broker.model")

const Position = sequelize.define("Position", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: User,
      key: "id",
    },
  },
  brokerId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    references: {
      model: Broker,
      key: "id",
    },
  },
  symbol: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  quantity: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: false,
  },
  averagePrice: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: false,
  },
  currentPrice: {
    type: DataTypes.DECIMAL(15, 6),
    allowNull: true,
  },
  marketValue: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: true,
  },
  unrealizedPnL: {
    type: DataTypes.DECIMAL(15, 2),
    allowNull: true,
  },
  unrealizedPnLPercent: {
    type: DataTypes.DECIMAL(10, 2),
    allowNull: true,
  },
  assetType: {
    type: DataTypes.ENUM("stock", "etf", "option"),
    allowNull: false,
  },
  optionData: {
    type: DataTypes.JSON,
    allowNull: true,
  },
  lastUpdated: {
    type: DataTypes.DATE,
    defaultValue: DataTypes.NOW,
  },
})

// Associations
Position.belongsTo(User, { foreignKey: "userId" })
Position.belongsTo(Broker, { foreignKey: "brokerId" })

module.exports = Position
