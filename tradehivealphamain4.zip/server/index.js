require("dotenv").config()
const express = require("express")
const cors = require("cors")
const path = require("path")
const { sequelize } = require("./config/database")
const { initWebSocket } = require("./websocket")
const { initSchedulers } = require("./services/scheduler.service")

// Import routes
const authRoutes = require("./routes/auth.routes")
const brokerRoutes = require("./routes/broker.routes")
const tradeRoutes = require("./routes/trade.routes")
const settingsRoutes = require("./routes/settings.routes")
const symbolRoutes = require("./routes/symbol.routes")
const activityRoutes = require("./routes/activity.routes")
const notificationRoutes = require("./routes/notification.routes")
const adminRoutes = require("./routes/admin.routes")

// Create Express app
const app = express()

// Middleware
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

// API routes
app.use("/api/auth", authRoutes)
app.use("/api/brokers", brokerRoutes)
app.use("/api/trades", tradeRoutes)
app.use("/api/settings", settingsRoutes)
app.use("/api/symbols", symbolRoutes)
app.use("/api/activity", activityRoutes)
app.use("/api/notifications", notificationRoutes)
app.use("/api/admin", adminRoutes)

// Serve static files from the React app
app.use(express.static(path.join(__dirname, "../dist")))

// The "catchall" handler for any request that doesn't match the ones above
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "../dist/index.html"))
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).send({ message: "Something broke!" })
})

// Start server
const PORT = process.env.PORT || 5000

const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})

// Initialize WebSocket server
const wss = initWebSocket(server)

// Initialize schedulers
initSchedulers()

// Sync database and create initial admin user if needed
sequelize
  .sync({ alter: true })
  .then(async () => {
    const { User } = require("./models")

    // Check if admin user exists
    const adminExists = await User.findOne({ where: { isAdmin: true } })

    if (!adminExists) {
      // Create default admin user
      await User.create({
        username: "admin",
        password: "admin123", // This will be hashed by the model hooks
        email: "admin@example.com",
        isAdmin: true,
      })

      console.log("Default admin user created")
    }
  })
  .catch((err) => {
    console.error("Database sync error:", err)
  })

// Handle graceful shutdown
process.on("SIGTERM", () => {
  console.log("SIGTERM received, shutting down gracefully")
  server.close(() => {
    console.log("Server closed")
    process.exit(0)
  })
})

module.exports = { app, server }
