const jwt = require("jsonwebtoken")
const { User } = require("../models")

const verifyToken = (req, res, next) => {
  const token = req.headers["x-access-token"] || req.headers["authorization"]

  if (!token) {
    return res.status(403).send({ message: "No token provided!" })
  }

  const tokenValue = token.startsWith("Bearer ") ? token.slice(7) : token

  jwt.verify(tokenValue, process.env.JWT_SECRET, async (err, decoded) => {
    if (err) {
      return res.status(401).send({ message: "Unauthorized!" })
    }

    try {
      // Check if user still exists and is active
      const user = await User.findByPk(decoded.id)

      if (!user) {
        return res.status(401).send({ message: "User not found!" })
      }

      req.userId = decoded.id
      req.isAdmin = user.isAdmin
      next()
    } catch (error) {
      return res.status(500).send({ message: "Failed to authenticate token." })
    }
  })
}

const isAdmin = (req, res, next) => {
  if (!req.isAdmin) {
    return res.status(403).send({ message: "Require Admin Role!" })
  }
  next()
}

module.exports = {
  verifyToken,
  isAdmin,
}
