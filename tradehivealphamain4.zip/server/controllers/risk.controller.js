const { Setting, Trade, Position, Broker, Notification, ActivityLog } = require("../models")
const { sequelize } = require("../config/database")
const { Op } = require("sequelize")
const tastytrade = require("../services/tastytrade") // Import tastytrade service
const schwab = require("../services/schwab") // Import schwab service

exports.getRiskSettings = async (req, res) => {
  try {
    // Get risk settings
    const maxTradeSizePercent = await Setting.findOne({ where: { key: "maxTradeSizePercent" } })
    const maxDailyLossPercent = await Setting.findOne({ where: { key: "maxDailyLossPercent" } })
    const maxPositionsPerSymbol = await Setting.findOne({ where: { key: "maxPositionsPerSymbol" } })
    const maxTotalPositions = await Setting.findOne({ where: { key: "maxTotalPositions" } })
    const stopLossEnabled = await Setting.findOne({ where: { key: "stopLossEnabled" } })
    const stopLossPercent = await Setting.findOne({ where: { key: "stopLossPercent" } })

    return res.status(200).send({
      maxTradeSizePercent: maxTradeSizePercent ? Number.parseFloat(maxTradeSizePercent.value) : 5,
      maxDailyLossPercent: maxDailyLossPercent ? Number.parseFloat(maxDailyLossPercent.value) : 3,
      maxPositionsPerSymbol: maxPositionsPerSymbol ? Number.parseInt(maxPositionsPerSymbol.value) : 3,
      maxTotalPositions: maxTotalPositions ? Number.parseInt(maxTotalPositions.value) : 20,
      stopLossEnabled: stopLossEnabled ? stopLossEnabled.value === "true" : false,
      stopLossPercent: stopLossPercent ? Number.parseFloat(stopLossPercent.value) : 10,
    })
  } catch (error) {
    console.error("Get risk settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateRiskSettings = async (req, res) => {
  try {
    const {
      maxTradeSizePercent,
      maxDailyLossPercent,
      maxPositionsPerSymbol,
      maxTotalPositions,
      stopLossEnabled,
      stopLossPercent,
    } = req.body

    // Validate settings
    if (maxTradeSizePercent !== undefined && (isNaN(maxTradeSizePercent) || maxTradeSizePercent <= 0)) {
      return res.status(400).send({ message: "Max trade size percent must be a positive number." })
    }

    if (maxDailyLossPercent !== undefined && (isNaN(maxDailyLossPercent) || maxDailyLossPercent <= 0)) {
      return res.status(400).send({ message: "Max daily loss percent must be a positive number." })
    }

    if (maxPositionsPerSymbol !== undefined && (isNaN(maxPositionsPerSymbol) || maxPositionsPerSymbol <= 0)) {
      return res.status(400).send({ message: "Max positions per symbol must be a positive number." })
    }

    if (maxTotalPositions !== undefined && (isNaN(maxTotalPositions) || maxTotalPositions <= 0)) {
      return res.status(400).send({ message: "Max total positions must be a positive number." })
    }

    if (stopLossPercent !== undefined && (isNaN(stopLossPercent) || stopLossPercent <= 0)) {
      return res.status(400).send({ message: "Stop loss percent must be a positive number." })
    }

    // Update settings
    if (maxTradeSizePercent !== undefined) {
      await Setting.upsert({
        key: "maxTradeSizePercent",
        value: maxTradeSizePercent.toString(),
        type: "number",
        category: "risk",
        description: "Maximum trade size as percentage of account balance",
      })
    }

    if (maxDailyLossPercent !== undefined) {
      await Setting.upsert({
        key: "maxDailyLossPercent",
        value: maxDailyLossPercent.toString(),
        type: "number",
        category: "risk",
        description: "Maximum daily loss as percentage of account balance",
      })
    }

    if (maxPositionsPerSymbol !== undefined) {
      await Setting.upsert({
        key: "maxPositionsPerSymbol",
        value: maxPositionsPerSymbol.toString(),
        type: "number",
        category: "risk",
        description: "Maximum number of positions per symbol",
      })
    }

    if (maxTotalPositions !== undefined) {
      await Setting.upsert({
        key: "maxTotalPositions",
        value: maxTotalPositions.toString(),
        type: "number",
        category: "risk",
        description: "Maximum total number of positions",
      })
    }

    if (stopLossEnabled !== undefined) {
      await Setting.upsert({
        key: "stopLossEnabled",
        value: stopLossEnabled.toString(),
        type: "boolean",
        category: "risk",
        description: "Enable automatic stop loss",
      })
    }

    if (stopLossPercent !== undefined) {
      await Setting.upsert({
        key: "stopLossPercent",
        value: stopLossPercent.toString(),
        type: "number",
        category: "risk",
        description: "Stop loss percentage",
      })
    }

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateRiskSettings",
      details: {
        maxTradeSizePercent,
        maxDailyLossPercent,
        maxPositionsPerSymbol,
        maxTotalPositions,
        stopLossEnabled,
        stopLossPercent,
      },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Risk settings updated successfully." })
  } catch (error) {
    console.error("Update risk settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.checkRiskLimits = async (trade) => {
  try {
    const transaction = await sequelize.transaction()

    try {
      // Get broker
      const broker = await Broker.findByPk(trade.brokerId, { transaction })

      if (!broker) {
        await transaction.rollback()
        return { allowed: false, message: "Broker not found." }
      }

      // Get risk settings
      const maxTradeSizePercent = await Setting.findOne({
        where: { key: "maxTradeSizePercent" },
        transaction,
      })

      const maxDailyLossPercent = await Setting.findOne({
        where: { key: "maxDailyLossPercent" },
        transaction,
      })

      const maxPositionsPerSymbol = await Setting.findOne({
        where: { key: "maxPositionsPerSymbol" },
        transaction,
      })

      const maxTotalPositions = await Setting.findOne({
        where: { key: "maxTotalPositions" },
        transaction,
      })

      // Check trade size limit
      if (maxTradeSizePercent) {
        const maxSizePercent = Number.parseFloat(maxTradeSizePercent.value)
        const tradeValue = trade.quantity * trade.price
        const maxAllowedValue = (broker.accountBalance * maxSizePercent) / 100

        if (tradeValue > maxAllowedValue) {
          await transaction.rollback()
          return {
            allowed: false,
            message: `Trade exceeds maximum size of ${maxSizePercent}% of account balance.`,
          }
        }
      }

      // Check daily loss limit
      if (maxDailyLossPercent) {
        const maxLossPercent = Number.parseFloat(maxDailyLossPercent.value)
        const maxLossAmount = (broker.accountBalance * maxLossPercent) / 100

        // Get today's realized losses
        const today = new Date()
        today.setHours(0, 0, 0, 0)

        const todayTrades = await Trade.findAll({
          where: {
            brokerId: broker.id,
            status: "filled",
            createdAt: {
              [Op.gte]: today,
            },
          },
          transaction,
        })

        // Calculate realized P&L for today
        let realizedPnL = 0

        for (const t of todayTrades) {
          // Simple P&L calculation (not accounting for previous positions)
          const tradePnL = t.side === "sell" ? t.quantity * t.price : -t.quantity * t.price
          realizedPnL += tradePnL
        }

        // If we're already at a loss and this is a buy trade, check if it would exceed the limit
        if (realizedPnL < 0 && trade.side === "buy") {
          const potentialAdditionalLoss = trade.quantity * trade.price

          if (Math.abs(realizedPnL) + potentialAdditionalLoss > maxLossAmount) {
            await transaction.rollback()
            return {
              allowed: false,
              message: `Trade would exceed maximum daily loss of ${maxLossPercent}% of account balance.`,
            }
          }
        }
      }

      // Check positions per symbol limit
      if (maxPositionsPerSymbol) {
        const maxPositions = Number.parseInt(maxPositionsPerSymbol.value)

        const symbolPositions = await Position.count({
          where: {
            brokerId: broker.id,
            symbol: trade.symbol,
          },
          transaction,
        })

        if (symbolPositions >= maxPositions) {
          await transaction.rollback()
          return {
            allowed: false,
            message: `Maximum of ${maxPositions} positions allowed per symbol.`,
          }
        }
      }

      // Check total positions limit
      if (maxTotalPositions) {
        const maxPositions = Number.parseInt(maxTotalPositions.value)

        const totalPositions = await Position.count({
          where: {
            brokerId: broker.id,
          },
          transaction,
        })

        if (totalPositions >= maxPositions) {
          await transaction.rollback()
          return {
            allowed: false,
            message: `Maximum of ${maxPositions} total positions allowed.`,
          }
        }
      }

      await transaction.commit()
      return { allowed: true }
    } catch (error) {
      await transaction.rollback()
      console.error("Check risk limits error:", error)
      return { allowed: false, message: "Error checking risk limits." }
    }
  } catch (error) {
    console.error("Check risk limits outer error:", error)
    return { allowed: false, message: "Internal server error." }
  }
}

exports.checkStopLosses = async () => {
  try {
    const transaction = await sequelize.transaction()

    try {
      // Get stop loss settings
      const stopLossEnabled = await Setting.findOne({
        where: { key: "stopLossEnabled" },
        transaction,
      })

      if (!stopLossEnabled || stopLossEnabled.value !== "true") {
        await transaction.rollback()
        return { success: true, message: "Stop loss is disabled." }
      }

      const stopLossPercent = await Setting.findOne({
        where: { key: "stopLossPercent" },
        transaction,
      })

      if (!stopLossPercent) {
        await transaction.rollback()
        return { success: false, message: "Stop loss percentage not found." }
      }

      const lossPercent = Number.parseFloat(stopLossPercent.value)

      // Get all positions
      const positions = await Position.findAll({
        include: [{ model: Broker }],
        transaction,
      })

      const closedPositions = []

      for (const position of positions) {
        // Calculate unrealized P&L percent
        const unrealizedPnLPercent = ((position.currentPrice - position.averagePrice) / position.averagePrice) * 100

        // Check if position has hit stop loss
        if (position.quantity > 0 && unrealizedPnLPercent <= -lossPercent) {
          // Position has hit stop loss, close it
          const broker = position.Broker

          if (!broker || !broker.isConnected) {
            continue
          }

          // Place order to close position
          let orderResult

          if (broker.brokerType === "tastytrade") {
            orderResult = await tastytrade.placeOrder(
              broker.accessToken,
              broker.accountId,
              position.symbol,
              "sell",
              position.quantity,
              "market",
              null,
              "day",
              position.assetType,
              position.optionData,
            )
          } else if (broker.brokerType === "schwab") {
            orderResult = await schwab.placeOrder(
              broker.accessToken,
              broker.accountId,
              position.symbol,
              "sell",
              position.quantity,
              "market",
              null,
              "day",
              position.assetType,
              position.optionData,
            )
          }

          if (orderResult.success) {
            // Create trade record
            const trade = await Trade.create(
              {
                userId: position.userId,
                brokerId: position.brokerId,
                brokerOrderId: orderResult.orderId,
                symbol: position.symbol,
                side: "sell",
                quantity: position.quantity,
                orderType: "market",
                timeInForce: "day",
                status: "pending",
                assetType: position.assetType,
                optionData: position.optionData,
                isManual: false,
                notes: `Automatic stop loss (${lossPercent}%)`,
              },
              { transaction },
            )

            closedPositions.push({
              symbol: position.symbol,
              quantity: position.quantity,
              tradeId: trade.id,
            })

            // Create notification
            await Notification.create(
              {
                userId: position.userId,
                type: "risk",
                severity: "warning",
                message: `Stop loss triggered for ${position.symbol}`,
                details: {
                  symbol: position.symbol,
                  quantity: position.quantity,
                  lossPercent: unrealizedPnLPercent,
                  stopLossPercent: lossPercent,
                },
              },
              { transaction },
            )

            // Log activity
            await ActivityLog.create(
              {
                userId: position.userId,
                action: "stopLossTriggered",
                details: {
                  symbol: position.symbol,
                  quantity: position.quantity,
                  lossPercent: unrealizedPnLPercent,
                  stopLossPercent: lossPercent,
                  tradeId: trade.id,
                },
              },
              { transaction },
            )
          }
        }
      }

      await transaction.commit()

      return {
        success: true,
        closedPositions,
      }
    } catch (error) {
      await transaction.rollback()
      console.error("Check stop losses error:", error)
      return { success: false, message: "Error checking stop losses." }
    }
  } catch (error) {
    console.error("Check stop losses outer error:", error)
    return { success: false, message: "Internal server error." }
  }
}

exports.getDailyRiskReport = async (req, res) => {
  try {
    // Get broker accounts
    const brokers = await Broker.findAll({
      where: { userId: req.userId },
    })

    const report = {
      totalAccountValue: 0,
      totalUnrealizedPnL: 0,
      totalUnrealizedPnLPercent: 0,
      maxDrawdown: 0,
      riskBySymbol: {},
      riskByBroker: {},
    }

    // Calculate total account value
    for (const broker of brokers) {
      report.totalAccountValue += broker.accountBalance

      // Initialize broker risk data
      report.riskByBroker[broker.id] = {
        brokerType: broker.brokerType,
        accountId: broker.accountId,
        accountBalance: broker.accountBalance,
        unrealizedPnL: 0,
        unrealizedPnLPercent: 0,
        positions: 0,
      }
    }

    // Get all positions
    const positions = await Position.findAll({
      where: {
        userId: req.userId,
      },
      include: [{ model: Broker }],
    })

    // Calculate risk metrics
    for (const position of positions) {
      // Update total unrealized P&L
      report.totalUnrealizedPnL += position.unrealizedPnL

      // Update broker risk data
      const brokerRisk = report.riskByBroker[position.brokerId]
      if (brokerRisk) {
        brokerRisk.unrealizedPnL += position.unrealizedPnL
        brokerRisk.positions += 1
      }

      // Update symbol risk data
      if (!report.riskBySymbol[position.symbol]) {
        report.riskBySymbol[position.symbol] = {
          totalQuantity: 0,
          totalValue: 0,
          unrealizedPnL: 0,
          unrealizedPnLPercent: 0,
        }
      }

      const symbolRisk = report.riskBySymbol[position.symbol]
      symbolRisk.totalQuantity += position.quantity
      symbolRisk.totalValue += position.marketValue
      symbolRisk.unrealizedPnL += position.unrealizedPnL
    }

    // Calculate percentages
    if (report.totalAccountValue > 0) {
      report.totalUnrealizedPnLPercent = (report.totalUnrealizedPnL / report.totalAccountValue) * 100
    }

    for (const brokerId in report.riskByBroker) {
      const brokerRisk = report.riskByBroker[brokerId]
      if (brokerRisk.accountBalance > 0) {
        brokerRisk.unrealizedPnLPercent = (brokerRisk.unrealizedPnL / brokerRisk.accountBalance) * 100
      }
    }

    for (const symbol in report.riskBySymbol) {
      const symbolRisk = report.riskBySymbol[symbol]
      if (symbolRisk.totalValue > 0) {
        symbolRisk.unrealizedPnLPercent = (symbolRisk.unrealizedPnL / symbolRisk.totalValue) * 100
      }
    }

    // Calculate max drawdown (worst performing symbol)
    let maxDrawdownSymbol = null
    let maxDrawdownPercent = 0

    for (const symbol in report.riskBySymbol) {
      const symbolRisk = report.riskBySymbol[symbol]
      if (symbolRisk.unrealizedPnLPercent < maxDrawdownPercent) {
        maxDrawdownSymbol = symbol
        maxDrawdownPercent = symbolRisk.unrealizedPnLPercent
      }
    }

    report.maxDrawdown = {
      symbol: maxDrawdownSymbol,
      percent: maxDrawdownPercent,
    }

    return res.status(200).send(report)
  } catch (error) {
    console.error("Get daily risk report error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
