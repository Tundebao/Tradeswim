const { Symbol, ActivityLog } = require("../models")
const { Op } = require("sequelize")

exports.getSymbols = async (req, res) => {
  try {
    const { search, type, isAllowed } = req.query

    const where = {}

    if (search) {
      where[Op.or] = [{ symbol: { [Op.like]: `%${search}%` } }, { name: { [Op.like]: `%${search}%` } }]
    }

    if (type) {
      where.type = type
    }

    if (isAllowed !== undefined) {
      where.isAllowed = isAllowed === "true"
    }

    const symbols = await Symbol.findAll({ where })

    return res.status(200).send(symbols)
  } catch (error) {
    console.error("Get symbols error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getSymbol = async (req, res) => {
  try {
    const { symbol } = req.params

    const symbolData = await Symbol.findOne({
      where: { symbol },
    })

    if (!symbolData) {
      return res.status(404).send({ message: "Symbol not found." })
    }

    return res.status(200).send(symbolData)
  } catch (error) {
    console.error("Get symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.createSymbol = async (req, res) => {
  try {
    const { symbol, name, type, exchange, isAllowed, notes } = req.body

    if (!symbol || !name || !type) {
      return res.status(400).send({ message: "Symbol, name, and type are required." })
    }

    // Check if symbol already exists
    const existingSymbol = await Symbol.findOne({
      where: { symbol },
    })

    if (existingSymbol) {
      return res.status(400).send({ message: "Symbol already exists." })
    }

    // Create symbol
    const newSymbol = await Symbol.create({
      symbol,
      name,
      type,
      exchange,
      isAllowed: isAllowed !== undefined ? isAllowed : true,
      notes,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "createSymbol",
      details: { symbol, name, type },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(201).send(newSymbol)
  } catch (error) {
    console.error("Create symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateSymbol = async (req, res) => {
  try {
    const { symbol } = req.params
    const { name, type, exchange, isAllowed, notes } = req.body

    const symbolData = await Symbol.findOne({
      where: { symbol },
    })

    if (!symbolData) {
      return res.status(404).send({ message: "Symbol not found." })
    }

    // Update symbol
    await symbolData.update({
      name: name || symbolData.name,
      type: type || symbolData.type,
      exchange: exchange || symbolData.exchange,
      isAllowed: isAllowed !== undefined ? isAllowed : symbolData.isAllowed,
      notes: notes !== undefined ? notes : symbolData.notes,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateSymbol",
      details: { symbol, name, type, isAllowed },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send(symbolData)
  } catch (error) {
    console.error("Update symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.deleteSymbol = async (req, res) => {
  try {
    const { symbol } = req.params

    const symbolData = await Symbol.findOne({
      where: { symbol },
    })

    if (!symbolData) {
      return res.status(404).send({ message: "Symbol not found." })
    }

    // Delete symbol
    await symbolData.destroy()

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "deleteSymbol",
      details: { symbol },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Symbol deleted successfully." })
  } catch (error) {
    console.error("Delete symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.bulkUpdateSymbols = async (req, res) => {
  try {
    const { symbols } = req.body

    if (!Array.isArray(symbols)) {
      return res.status(400).send({ message: "Symbols must be an array." })
    }

    // Update symbols
    for (const symbolData of symbols) {
      if (!symbolData.symbol) continue

      const existingSymbol = await Symbol.findOne({
        where: { symbol: symbolData.symbol },
      })

      if (existingSymbol) {
        await existingSymbol.update({
          name: symbolData.name || existingSymbol.name,
          type: symbolData.type || existingSymbol.type,
          exchange: symbolData.exchange || existingSymbol.exchange,
          isAllowed: symbolData.isAllowed !== undefined ? symbolData.isAllowed : existingSymbol.isAllowed,
          notes: symbolData.notes !== undefined ? symbolData.notes : existingSymbol.notes,
        })
      } else {
        await Symbol.create({
          symbol: symbolData.symbol,
          name: symbolData.name || "",
          type: symbolData.type || "stock",
          exchange: symbolData.exchange || "",
          isAllowed: symbolData.isAllowed !== undefined ? symbolData.isAllowed : true,
          notes: symbolData.notes || "",
        })
      }
    }

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "bulkUpdateSymbols",
      details: { count: symbols.length },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Symbols updated successfully." })
  } catch (error) {
    console.error("Bulk update symbols error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
