const { Broker, User, Notification, ActivityLog } = require("../models")
const tastytrade = require("../services/tastytrade.service")
const schwab = require("../services/schwab.service")

exports.connectTastytrade = async (req, res) => {
  try {
    const { username, password } = req.body

    if (!username || !password) {
      return res.status(400).send({ message: "Username and password are required." })
    }

    // Authenticate with Tastytrade
    const authResult = await tastytrade.authenticate(username, password)

    if (!authResult.success) {
      return res.status(401).send({ message: authResult.message })
    }

    // Get account information
    const accountInfo = await tastytrade.getAccountInfo(authResult.session_token)

    if (!accountInfo.success) {
      return res.status(500).send({ message: accountInfo.message })
    }

    // Check if broker already exists
    let broker = await Broker.findOne({
      where: {
        userId: req.userId,
        brokerType: "tastytrade",
        accountId: accountInfo.account.account_number,
      },
    })

    if (broker) {
      // Update existing broker
      broker = await broker.update({
        accessToken: authResult.session_token,
        isConnected: true,
        accountBalance: accountInfo.account.equity,
        buyingPower: accountInfo.account.buying_power,
        lastSyncTime: new Date(),
      })
    } else {
      // Create new broker
      broker = await Broker.create({
        userId: req.userId,
        brokerType: "tastytrade",
        accountId: accountInfo.account.account_number,
        accessToken: authResult.session_token,
        isConnected: true,
        accountBalance: accountInfo.account.equity,
        buyingPower: accountInfo.account.buying_power,
        lastSyncTime: new Date(),
      })
    }

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "connectBroker",
      details: { brokerType: "tastytrade", accountId: accountInfo.account.account_number },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification
    await Notification.create({
      userId: req.userId,
      type: "broker",
      severity: "info",
      message: `Connected to Tastytrade account ${accountInfo.account.account_number}`,
      details: { brokerType: "tastytrade", accountId: accountInfo.account.account_number },
    })

    return res.status(200).send({
      message: "Connected to Tastytrade successfully",
      broker: {
        id: broker.id,
        brokerType: broker.brokerType,
        accountId: broker.accountId,
        isConnected: broker.isConnected,
        accountBalance: broker.accountBalance,
        buyingPower: broker.buyingPower,
      },
    })
  } catch (error) {
    console.error("Connect Tastytrade error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.initiateSchwabAuth = async (req, res) => {
  try {
    // Generate authorization URL
    const authUrl = schwab.getAuthorizationUrl()

    return res.status(200).send({ authUrl })
  } catch (error) {
    console.error("Initiate Schwab auth error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.completeSchwabAuth = async (req, res) => {
  try {
    const { code } = req.body

    if (!code) {
      return res.status(400).send({ message: "Authorization code is required." })
    }

    // Exchange code for tokens
    const tokenResult = await schwab.exchangeCodeForTokens(code)

    if (!tokenResult.success) {
      return res.status(401).send({ message: tokenResult.message })
    }

    // Get account information
    const accountInfo = await schwab.getAccountInfo(tokenResult.access_token)

    if (!accountInfo.success) {
      return res.status(500).send({ message: accountInfo.message })
    }

    // Process each account
    const brokers = []

    for (const account of accountInfo.accounts) {
      // Check if broker already exists
      let broker = await Broker.findOne({
        where: {
          userId: req.userId,
          brokerType: "schwab",
          accountId: account.accountId,
        },
      })

      const tokenExpiry = new Date()
      tokenExpiry.setSeconds(tokenExpiry.getSeconds() + tokenResult.expires_in)

      if (broker) {
        // Update existing broker
        broker = await broker.update({
          accessToken: tokenResult.access_token,
          refreshToken: tokenResult.refresh_token,
          tokenExpiry,
          isConnected: true,
          accountBalance: account.equity,
          buyingPower: account.buyingPower,
          marginAvailable: account.marginAvailable,
          lastSyncTime: new Date(),
        })
      } else {
        // Create new broker
        broker = await Broker.create({
          userId: req.userId,
          brokerType: "schwab",
          accountId: account.accountId,
          accessToken: tokenResult.access_token,
          refreshToken: tokenResult.refresh_token,
          tokenExpiry,
          isConnected: true,
          accountBalance: account.equity,
          buyingPower: account.buyingPower,
          marginAvailable: account.marginAvailable,
          lastSyncTime: new Date(),
        })
      }

      brokers.push({
        id: broker.id,
        brokerType: broker.brokerType,
        accountId: broker.accountId,
        isConnected: broker.isConnected,
        accountBalance: broker.accountBalance,
        buyingPower: broker.buyingPower,
      })
    }

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "connectBroker",
      details: { brokerType: "schwab", accountCount: accountInfo.accounts.length },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification
    await Notification.create({
      userId: req.userId,
      type: "broker",
      severity: "info",
      message: `Connected to ${accountInfo.accounts.length} Schwab account(s)`,
      details: { brokerType: "schwab", accountCount: accountInfo.accounts.length },
    })

    return res.status(200).send({
      message: "Connected to Schwab successfully",
      brokers,
    })
  } catch (error) {
    console.error("Complete Schwab auth error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.disconnectBroker = async (req, res) => {
  try {
    const { brokerId } = req.params

    const broker = await Broker.findOne({
      where: {
        id: brokerId,
        userId: req.userId,
      },
    })

    if (!broker) {
      return res.status(404).send({ message: "Broker not found." })
    }

    // Revoke tokens if applicable
    if (broker.brokerType === "schwab" && broker.accessToken) {
      await schwab.revokeToken(broker.accessToken)
    }

    // Update broker status
    await broker.update({
      isConnected: false,
      accessToken: null,
      refreshToken: null,
      tokenExpiry: null,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "disconnectBroker",
      details: { brokerType: broker.brokerType, accountId: broker.accountId },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification
    await Notification.create({
      userId: req.userId,
      type: "broker",
      severity: "info",
      message: `Disconnected from ${broker.brokerType} account ${broker.accountId}`,
      details: { brokerType: broker.brokerType, accountId: broker.accountId },
    })

    return res.status(200).send({ message: "Broker disconnected successfully." })
  } catch (error) {
    console.error("Disconnect broker error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getBrokers = async (req, res) => {
  try {
    const brokers = await Broker.findAll({
      where: { userId: req.userId },
      attributes: [
        "id",
        "brokerType",
        "accountId",
        "isConnected",
        "isMaster",
        "accountBalance",
        "buyingPower",
        "marginAvailable",
        "lastSyncTime",
      ],
    })

    return res.status(200).send(brokers)
  } catch (error) {
    console.error("Get brokers error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.setMasterBroker = async (req, res) => {
  try {
    const { brokerId } = req.params

    // Verify broker exists and belongs to user
    const broker = await Broker.findOne({
      where: {
        id: brokerId,
        userId: req.userId,
      },
    })

    if (!broker) {
      return res.status(404).send({ message: "Broker not found." })
    }

    // Reset all master flags
    await Broker.update({ isMaster: false }, { where: { userId: req.userId } })

    // Set new master broker
    await broker.update({ isMaster: true })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "setMasterBroker",
      details: { brokerType: broker.brokerType, accountId: broker.accountId },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Master broker set successfully." })
  } catch (error) {
    console.error("Set master broker error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.refreshBrokerData = async (req, res) => {
  try {
    const { brokerId } = req.params

    const broker = await Broker.findOne({
      where: {
        id: brokerId,
        userId: req.userId,
      },
    })

    if (!broker) {
      return res.status(404).send({ message: "Broker not found." })
    }

    if (!broker.isConnected) {
      return res.status(400).send({ message: "Broker is not connected." })
    }

    let accountInfo

    // Refresh broker data based on type
    if (broker.brokerType === "tastytrade") {
      accountInfo = await tastytrade.getAccountInfo(broker.accessToken)
    } else if (broker.brokerType === "schwab") {
      // Check if token needs refresh
      if (broker.tokenExpiry && new Date(broker.tokenExpiry) < new Date()) {
        const refreshResult = await schwab.refreshToken(broker.refreshToken)

        if (refreshResult.success) {
          const tokenExpiry = new Date()
          tokenExpiry.setSeconds(tokenExpiry.getSeconds() + refreshResult.expires_in)

          await broker.update({
            accessToken: refreshResult.access_token,
            refreshToken: refreshResult.refresh_token,
            tokenExpiry,
          })
        } else {
          return res.status(401).send({ message: "Failed to refresh token." })
        }
      }

      accountInfo = await schwab.getAccountInfo(broker.accessToken)
    }

    if (!accountInfo.success) {
      return res.status(500).send({ message: accountInfo.message })
    }

    // Update broker data
    if (broker.brokerType === "tastytrade") {
      await broker.update({
        accountBalance: accountInfo.account.equity,
        buyingPower: accountInfo.account.buying_power,
        lastSyncTime: new Date(),
      })
    } else if (broker.brokerType === "schwab") {
      const account = accountInfo.accounts.find((acc) => acc.accountId === broker.accountId)

      if (account) {
        await broker.update({
          accountBalance: account.equity,
          buyingPower: account.buyingPower,
          marginAvailable: account.marginAvailable,
          lastSyncTime: new Date(),
        })
      }
    }

    return res.status(200).send({
      message: "Broker data refreshed successfully",
      broker: {
        id: broker.id,
        brokerType: broker.brokerType,
        accountId: broker.accountId,
        isConnected: broker.isConnected,
        accountBalance: broker.accountBalance,
        buyingPower: broker.buyingPower,
        marginAvailable: broker.marginAvailable,
        lastSyncTime: broker.lastSyncTime,
      },
    })
  } catch (error) {
    console.error("Refresh broker data error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
