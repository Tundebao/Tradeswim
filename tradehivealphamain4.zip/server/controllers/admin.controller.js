const { Setting, Symbol, ActivityLog, User, Broker, Trade, CopyTrade, Notification } = require("../models")
const { sequelize } = require("../config/database")

exports.getSettings = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const settings = await Setting.findAll()

    return res.status(200).send(settings)
  } catch (error) {
    console.error("Get settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateSetting = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { key } = req.params
    const { value } = req.body

    const setting = await Setting.findOne({ where: { key } })

    if (!setting) {
      return res.status(404).send({ message: "Setting not found." })
    }

    // Validate value based on type
    if (setting.type === "boolean" && !["true", "false"].includes(value)) {
      return res.status(400).send({ message: "Invalid boolean value." })
    } else if (setting.type === "number" && isNaN(Number.parseFloat(value))) {
      return res.status(400).send({ message: "Invalid number value." })
    } else if (setting.type === "json") {
      try {
        JSON.parse(value)
      } catch (e) {
        return res.status(400).send({ message: "Invalid JSON value." })
      }
    }

    // Update setting
    await setting.update({ value })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateSetting",
      details: { key, value },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Setting updated successfully." })
  } catch (error) {
    console.error("Update setting error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.createSetting = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { key, value, type, category, description } = req.body

    // Check if setting already exists
    const existingSetting = await Setting.findOne({ where: { key } })

    if (existingSetting) {
      return res.status(400).send({ message: "Setting already exists." })
    }

    // Validate type
    if (!["boolean", "number", "string", "json"].includes(type)) {
      return res.status(400).send({ message: "Invalid setting type." })
    }

    // Validate category
    if (!["trading", "risk", "system", "notification"].includes(category)) {
      return res.status(400).send({ message: "Invalid setting category." })
    }

    // Create setting
    const setting = await Setting.create({
      key,
      value,
      type,
      category,
      description,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "createSetting",
      details: { key, value, type, category },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(201).send({
      message: "Setting created successfully",
      setting,
    })
  } catch (error) {
    console.error("Create setting error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.deleteSetting = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { key } = req.params

    const setting = await Setting.findOne({ where: { key } })

    if (!setting) {
      return res.status(404).send({ message: "Setting not found." })
    }

    // Delete setting
    await setting.destroy()

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "deleteSetting",
      details: { key },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Setting deleted successfully." })
  } catch (error) {
    console.error("Delete setting error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getSymbols = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const symbols = await Symbol.findAll()

    return res.status(200).send(symbols)
  } catch (error) {
    console.error("Get symbols error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.createSymbol = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { symbol, name, type, isAllowed, maxPositionSize, notes } = req.body

    // Check if symbol already exists
    const existingSymbol = await Symbol.findOne({ where: { symbol } })

    if (existingSymbol) {
      return res.status(400).send({ message: "Symbol already exists." })
    }

    // Validate type
    if (!["stock", "etf", "option"].includes(type)) {
      return res.status(400).send({ message: "Invalid symbol type." })
    }

    // Create symbol
    const newSymbol = await Symbol.create({
      symbol,
      name,
      type,
      isAllowed: isAllowed !== undefined ? isAllowed : true,
      maxPositionSize,
      notes,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "createSymbol",
      details: { symbol, type, isAllowed },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(201).send({
      message: "Symbol created successfully",
      symbol: newSymbol,
    })
  } catch (error) {
    console.error("Create symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateSymbol = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { symbolId } = req.params
    const { name, type, isAllowed, maxPositionSize, notes } = req.body

    const symbol = await Symbol.findByPk(symbolId)

    if (!symbol) {
      return res.status(404).send({ message: "Symbol not found." })
    }

    // Validate type if provided
    if (type && !["stock", "etf", "option"].includes(type)) {
      return res.status(400).send({ message: "Invalid symbol type." })
    }

    // Update symbol
    await symbol.update({
      name: name !== undefined ? name : symbol.name,
      type: type !== undefined ? type : symbol.type,
      isAllowed: isAllowed !== undefined ? isAllowed : symbol.isAllowed,
      maxPositionSize: maxPositionSize !== undefined ? maxPositionSize : symbol.maxPositionSize,
      notes: notes !== undefined ? notes : symbol.notes,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateSymbol",
      details: { symbolId, symbol: symbol.symbol, isAllowed },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Symbol updated successfully." })
  } catch (error) {
    console.error("Update symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.deleteSymbol = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { symbolId } = req.params

    const symbol = await Symbol.findByPk(symbolId)

    if (!symbol) {
      return res.status(404).send({ message: "Symbol not found." })
    }

    // Delete symbol
    await symbol.destroy()

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "deleteSymbol",
      details: { symbolId, symbol: symbol.symbol },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Symbol deleted successfully." })
  } catch (error) {
    console.error("Delete symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getActivityLogs = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const { userId, action, limit, offset } = req.query

    const where = {}

    if (userId) where.userId = userId
    if (action) where.action = action

    const logs = await ActivityLog.findAndCountAll({
      where,
      limit: limit ? Number.parseInt(limit) : 100,
      offset: offset ? Number.parseInt(offset) : 0,
      order: [["createdAt", "DESC"]],
      include: [{ model: User, attributes: ["username", "email"] }],
    })

    return res.status(200).send({
      count: logs.count,
      logs: logs.rows,
    })
  } catch (error) {
    console.error("Get activity logs error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getDashboardStats = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    // Get counts
    const brokerCount = await Broker.count({ where: { isConnected: true } })
    const tradeCount = await Trade.count()
    const copyTradeCount = await CopyTrade.count()
    const pendingTradeCount = await Trade.count({ where: { status: "pending" } })

    // Get recent trades
    const recentTrades = await Trade.findAll({
      limit: 10,
      order: [["createdAt", "DESC"]],
      include: [
        { model: Broker, attributes: ["brokerType", "accountId"] },
        { model: User, attributes: ["username"] },
      ],
    })

    // Get recent copy trades
    const recentCopyTrades = await CopyTrade.findAll({
      limit: 10,
      order: [["createdAt", "DESC"]],
      include: [
        { model: Broker, as: "sourceBroker", attributes: ["brokerType", "accountId"] },
        { model: Broker, as: "targetBroker", attributes: ["brokerType", "accountId"] },
        { model: Trade, as: "sourceTrade", attributes: ["symbol", "side", "quantity"] },
        { model: Trade, as: "targetTrade", attributes: ["symbol", "side", "quantity"] },
      ],
    })

    // Get recent notifications
    const recentNotifications = await Notification.findAll({
      limit: 10,
      order: [["createdAt", "DESC"]],
      include: [{ model: User, attributes: ["username"] }],
    })

    return res.status(200).send({
      stats: {
        brokerCount,
        tradeCount,
        copyTradeCount,
        pendingTradeCount,
      },
      recentTrades,
      recentCopyTrades,
      recentNotifications,
    })
  } catch (error) {
    console.error("Get dashboard stats error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.initializeDefaultSettings = async (req, res) => {
  try {
    if (!req.isAdmin) {
      return res.status(403).send({ message: "Unauthorized access." })
    }

    const transaction = await sequelize.transaction()

    try {
      // Define default settings
      const defaultSettings = [
        {
          key: "copyTradingEnabled",
          value: "false",
          type: "boolean",
          category: "trading",
          description: "Enable or disable copy trading",
        },
        {
          key: "copyTradeLogic",
          value: "exactSize",
          type: "string",
          category: "trading",
          description: "Copy trade sizing logic (exactSize, fixedSize, percentBalance)",
        },
        {
          key: "copyTradeValue",
          value: "100",
          type: "number",
          category: "trading",
          description: "Value for fixedSize or percentBalance copy logic",
        },
        {
          key: "maxTradeSizePercent",
          value: "10",
          type: "number",
          category: "risk",
          description: "Maximum trade size as percentage of account balance",
        },
        {
          key: "maxDailyDrawdownPercent",
          value: "5",
          type: "number",
          category: "risk",
          description: "Maximum daily drawdown as percentage of account balance",
        },
        {
          key: "tradingEnabled",
          value: "true",
          type: "boolean",
          category: "trading",
          description: "Enable or disable all trading",
        },
        {
          key: "tradeDelayMs",
          value: "500",
          type: "number",
          category: "trading",
          description: "Delay between trades in milliseconds",
        },
        {
          key: "loggingEnabled",
          value: "true",
          type: "boolean",
          category: "system",
          description: "Enable or disable activity logging",
        },
        {
          key: "webhookUrl",
          value: "",
          type: "string",
          category: "notification",
          description: "Webhook URL for trade notifications",
        },
      ]

      // Create settings if they don't exist
      for (const setting of defaultSettings) {
        const [, created] = await Setting.findOrCreate({
          where: { key: setting.key },
          defaults: setting,
          transaction,
        })

        if (created) {
          console.log(`Created setting: ${setting.key}`)
        }
      }

      // Log activity
      await ActivityLog.create(
        {
          userId: req.userId,
          action: "initializeDefaultSettings",
          ipAddress: req.ip,
          userAgent: req.headers["user-agent"],
        },
        { transaction },
      )

      await transaction.commit()

      return res.status(200).send({ message: "Default settings initialized successfully." })
    } catch (error) {
      await transaction.rollback()
      console.error("Initialize default settings transaction error:", error)
      return res.status(500).send({ message: "Internal server error." })
    }
  } catch (error) {
    console.error("Initialize default settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
