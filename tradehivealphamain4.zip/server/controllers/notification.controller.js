const { Notification } = require("../models")

exports.getNotifications = async (req, res) => {
  try {
    const { limit, offset, isRead } = req.query

    const where = { userId: req.userId }

    if (isRead !== undefined) {
      where.isRead = isRead === "true"
    }

    const notifications = await Notification.findAndCountAll({
      where,
      limit: limit ? Number.parseInt(limit) : 100,
      offset: offset ? Number.parseInt(offset) : 0,
      order: [["createdAt", "DESC"]],
    })

    return res.status(200).send({
      count: notifications.count,
      notifications: notifications.rows,
    })
  } catch (error) {
    console.error("Get notifications error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.markAsRead = async (req, res) => {
  try {
    const { notificationId } = req.params

    const notification = await Notification.findOne({
      where: {
        id: notificationId,
        userId: req.userId,
      },
    })

    if (!notification) {
      return res.status(404).send({ message: "Notification not found." })
    }

    await notification.update({ isRead: true })

    return res.status(200).send({ message: "Notification marked as read." })
  } catch (error) {
    console.error("Mark notification as read error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.markAllAsRead = async (req, res) => {
  try {
    await Notification.update({ isRead: true }, { where: { userId: req.userId, isRead: false } })

    return res.status(200).send({ message: "All notifications marked as read." })
  } catch (error) {
    console.error("Mark all notifications as read error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.deleteNotification = async (req, res) => {
  try {
    const { notificationId } = req.params

    const notification = await Notification.findOne({
      where: {
        id: notificationId,
        userId: req.userId,
      },
    })

    if (!notification) {
      return res.status(404).send({ message: "Notification not found." })
    }

    await notification.destroy()

    return res.status(200).send({ message: "Notification deleted successfully." })
  } catch (error) {
    console.error("Delete notification error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.clearAllNotifications = async (req, res) => {
  try {
    await Notification.destroy({
      where: { userId: req.userId },
    })

    return res.status(200).send({ message: "All notifications cleared successfully." })
  } catch (error) {
    console.error("Clear all notifications error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
