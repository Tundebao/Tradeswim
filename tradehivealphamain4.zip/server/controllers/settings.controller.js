const { Setting, ActivityLog } = require("../models")

exports.getSettings = async (req, res) => {
  try {
    const settings = await Setting.findAll()

    // Convert to key-value object
    const settingsObject = settings.reduce((obj, setting) => {
      obj[setting.key] = setting.value
      return obj
    }, {})

    return res.status(200).send(settingsObject)
  } catch (error) {
    console.error("Get settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateSettings = async (req, res) => {
  try {
    const { settings } = req.body

    if (!settings || typeof settings !== "object") {
      return res.status(400).send({ message: "Settings object is required." })
    }

    // Update or create settings
    for (const [key, value] of Object.entries(settings)) {
      await Setting.upsert({
        key,
        value: String(value),
      })
    }

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateSettings",
      details: { settings },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Settings updated successfully." })
  } catch (error) {
    console.error("Update settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getCopyTradingSettings = async (req, res) => {
  try {
    const copyTradingEnabled = await Setting.findOne({ where: { key: "copyTradingEnabled" } })
    const copyTradeLogic = await Setting.findOne({ where: { key: "copyTradeLogic" } })
    const copyTradeValue = await Setting.findOne({ where: { key: "copyTradeValue" } })
    const maxTradeSize = await Setting.findOne({ where: { key: "maxTradeSizePercent" } })
    const maxDailyLoss = await Setting.findOne({ where: { key: "maxDailyLossPercent" } })

    const settings = {
      copyTradingEnabled: copyTradingEnabled ? copyTradingEnabled.value === "true" : false,
      copyTradeLogic: copyTradeLogic ? copyTradeLogic.value : "mirror",
      copyTradeValue: copyTradeValue ? Number.parseFloat(copyTradeValue.value) : 100,
      maxTradeSizePercent: maxTradeSize ? Number.parseFloat(maxTradeSize.value) : 5,
      maxDailyLossPercent: maxDailyLoss ? Number.parseFloat(maxDailyLoss.value) : 3,
    }

    return res.status(200).send(settings)
  } catch (error) {
    console.error("Get copy trading settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateCopyTradingSettings = async (req, res) => {
  try {
    const { copyTradingEnabled, copyTradeLogic, copyTradeValue, maxTradeSizePercent, maxDailyLossPercent } = req.body

    // Validate settings
    if (copyTradeLogic && !["mirror", "fixedSize", "percentBalance"].includes(copyTradeLogic)) {
      return res.status(400).send({ message: "Invalid copy trade logic." })
    }

    if (copyTradeValue !== undefined && (isNaN(copyTradeValue) || copyTradeValue <= 0)) {
      return res.status(400).send({ message: "Copy trade value must be a positive number." })
    }

    if (maxTradeSizePercent !== undefined && (isNaN(maxTradeSizePercent) || maxTradeSizePercent <= 0)) {
      return res.status(400).send({ message: "Max trade size percent must be a positive number." })
    }

    if (maxDailyLossPercent !== undefined && (isNaN(maxDailyLossPercent) || maxDailyLossPercent <= 0)) {
      return res.status(400).send({ message: "Max daily loss percent must be a positive number." })
    }

    // Update settings
    if (copyTradingEnabled !== undefined) {
      await Setting.upsert({
        key: "copyTradingEnabled",
        value: copyTradingEnabled.toString(),
      })
    }

    if (copyTradeLogic) {
      await Setting.upsert({
        key: "copyTradeLogic",
        value: copyTradeLogic,
      })
    }

    if (copyTradeValue !== undefined) {
      await Setting.upsert({
        key: "copyTradeValue",
        value: copyTradeValue.toString(),
      })
    }

    if (maxTradeSizePercent !== undefined) {
      await Setting.upsert({
        key: "maxTradeSizePercent",
        value: maxTradeSizePercent.toString(),
      })
    }

    if (maxDailyLossPercent !== undefined) {
      await Setting.upsert({
        key: "maxDailyLossPercent",
        value: maxDailyLossPercent.toString(),
      })
    }

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateCopyTradingSettings",
      details: {
        copyTradingEnabled,
        copyTradeLogic,
        copyTradeValue,
        maxTradeSizePercent,
        maxDailyLossPercent,
      },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Copy trading settings updated successfully." })
  } catch (error) {
    console.error("Update copy trading settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getSymbolSettings = async (req, res) => {
  try {
    const allowedSymbols = await Setting.findOne({ where: { key: "allowedSymbols" } })

    const settings = {
      allowedSymbols: allowedSymbols ? JSON.parse(allowedSymbols.value) : [],
    }

    return res.status(200).send(settings)
  } catch (error) {
    console.error("Get symbol settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateSymbolSettings = async (req, res) => {
  try {
    const { allowedSymbols } = req.body

    if (!Array.isArray(allowedSymbols)) {
      return res.status(400).send({ message: "Allowed symbols must be an array." })
    }

    // Update settings
    await Setting.upsert({
      key: "allowedSymbols",
      value: JSON.stringify(allowedSymbols),
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateSymbolSettings",
      details: { allowedSymbols },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Symbol settings updated successfully." })
  } catch (error) {
    console.error("Update symbol settings error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
