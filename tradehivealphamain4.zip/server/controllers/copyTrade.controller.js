const { CopyTrade, Trade, Broker, Setting, Notification, ActivityLog } = require("../models")
const { sequelize } = require("../config/database")
const tastytrade = require("../services/tastytrade.service")
const schwab = require("../services/schwab.service")

exports.getCopyTradingStatus = async (req, res) => {
  try {
    // Get copy trading settings
    const copyTradingEnabled = await Setting.findOne({ where: { key: "copyTradingEnabled" } })

    // Get master broker
    const masterBroker = await Broker.findOne({
      where: {
        userId: req.userId,
        isMaster: true,
        isConnected: true,
      },
    })

    // Get follower brokers
    const followerBrokers = await Broker.findAll({
      where: {
        userId: req.userId,
        isMaster: false,
        isConnected: true,
      },
    })

    // Get recent copy trades
    const recentCopyTrades = await CopyTrade.findAll({
      where: {
        sourceBroker: { userId: req.userId },
      },
      limit: 5,
      order: [["createdAt", "DESC"]],
      include: [
        { model: Broker, as: "sourceBroker", attributes: ["accountId", "brokerType"] },
        { model: Broker, as: "targetBroker", attributes: ["accountId", "brokerType"] },
        { model: Trade, as: "sourceTrade", attributes: ["symbol", "side", "quantity", "price"] },
        { model: Trade, as: "targetTrade", attributes: ["symbol", "side", "quantity", "price"] },
      ],
    })

    return res.status(200).send({
      isEnabled: copyTradingEnabled ? copyTradingEnabled.value === "true" : false,
      masterBroker: masterBroker
        ? {
            id: masterBroker.id,
            accountId: masterBroker.accountId,
            brokerType: masterBroker.brokerType,
          }
        : null,
      followerCount: followerBrokers.length,
      followers: followerBrokers.map((broker) => ({
        id: broker.id,
        accountId: broker.accountId,
        brokerType: broker.brokerType,
      })),
      recentCopyTrades: recentCopyTrades.map((ct) => ({
        id: ct.id,
        status: ct.status,
        createdAt: ct.createdAt,
        sourceBroker: ct.sourceBroker
          ? {
              accountId: ct.sourceBroker.accountId,
              brokerType: ct.sourceBroker.brokerType,
            }
          : null,
        targetBroker: ct.targetBroker
          ? {
              accountId: ct.targetBroker.accountId,
              brokerType: ct.targetBroker.brokerType,
            }
          : null,
        sourceTrade: ct.sourceTrade
          ? {
              symbol: ct.sourceTrade.symbol,
              side: ct.sourceTrade.side,
              quantity: ct.sourceTrade.quantity,
              price: ct.sourceTrade.price,
            }
          : null,
        targetTrade: ct.targetTrade
          ? {
              symbol: ct.targetTrade.symbol,
              side: ct.targetTrade.side,
              quantity: ct.targetTrade.quantity,
              price: ct.targetTrade.price,
            }
          : null,
      })),
    })
  } catch (error) {
    console.error("Get copy trading status error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.toggleCopyTrading = async (req, res) => {
  try {
    const { enabled } = req.body

    if (enabled === undefined) {
      return res.status(400).send({ message: "Enabled status is required." })
    }

    // Update copy trading setting
    await Setting.upsert({
      key: "copyTradingEnabled",
      value: enabled.toString(),
      type: "boolean",
      category: "trading",
      description: "Enable or disable copy trading",
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "toggleCopyTrading",
      details: { enabled },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification
    await Notification.create({
      userId: req.userId,
      type: "system",
      severity: "info",
      message: `Copy trading ${enabled ? "enabled" : "disabled"}`,
      details: { enabled },
    })

    return res.status(200).send({ message: `Copy trading ${enabled ? "enabled" : "disabled"} successfully.` })
  } catch (error) {
    console.error("Toggle copy trading error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getCopyTrades = async (req, res) => {
  try {
    const { status, startDate, endDate, limit, offset } = req.query

    const where = { userId: req.userId }

    if (status) {
      where.status = status
    }

    if (startDate || endDate) {
      where.createdAt = {}

      if (startDate) {
        where.createdAt[sequelize.Op.gte] = new Date(startDate)
      }

      if (endDate) {
        where.createdAt[sequelize.Op.lte] = new Date(endDate)
      }
    }

    const copyTrades = await CopyTrade.findAndCountAll({
      where,
      limit: limit ? Number.parseInt(limit) : 100,
      offset: offset ? Number.parseInt(offset) : 0,
      order: [["createdAt", "DESC"]],
      include: [
        { model: Broker, as: "sourceBroker", attributes: ["accountId", "brokerType"] },
        { model: Broker, as: "targetBroker", attributes: ["accountId", "brokerType"] },
        { model: Trade, as: "sourceTrade", attributes: ["symbol", "side", "quantity", "price"] },
        { model: Trade, as: "targetTrade", attributes: ["symbol", "side", "quantity", "price"] },
      ],
    })

    return res.status(200).send({
      count: copyTrades.count,
      copyTrades: copyTrades.rows,
    })
  } catch (error) {
    console.error("Get copy trades error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.executeCopyTrade = async (sourceTradeId, req) => {
  const transaction = await sequelize.transaction()

  try {
    // Get source trade
    const sourceTrade = await Trade.findOne({
      where: { id: sourceTradeId },
      include: [{ model: Broker }],
      transaction,
    })

    if (!sourceTrade) {
      await transaction.rollback()
      return { success: false, message: "Source trade not found." }
    }

    // Check if copy trading is enabled
    const copyTradingEnabled = await Setting.findOne({
      where: { key: "copyTradingEnabled" },
      transaction,
    })

    if (!copyTradingEnabled || copyTradingEnabled.value !== "true") {
      await transaction.rollback()
      return { success: false, message: "Copy trading is disabled." }
    }

    // Get copy trading settings
    const copyTradeLogic = await Setting.findOne({
      where: { key: "copyTradeLogic" },
      transaction,
    })

    const copyTradeValue = await Setting.findOne({
      where: { key: "copyTradeValue" },
      transaction,
    })

    if (!copyTradeLogic || !copyTradeValue) {
      await transaction.rollback()
      return { success: false, message: "Copy trading settings not found." }
    }

    // Get target brokers (all connected brokers except the source)
    const targetBrokers = await Broker.findAll({
      where: {
        userId: sourceTrade.userId,
        id: { [sequelize.Op.ne]: sourceTrade.brokerId },
        isConnected: true,
      },
      transaction,
    })

    if (targetBrokers.length === 0) {
      await transaction.rollback()
      return { success: false, message: "No target brokers found." }
    }

    const results = []

    // Process each target broker
    for (const targetBroker of targetBrokers) {
      let quantity = sourceTrade.quantity

      // Calculate quantity based on copy logic
      if (copyTradeLogic.value === "fixedSize") {
        // Fixed size in dollars
        const fixedAmount = Number.parseFloat(copyTradeValue.value)
        quantity = fixedAmount / sourceTrade.price
      } else if (copyTradeLogic.value === "percentBalance") {
        // Percentage of account balance
        const percentDecimal = Number.parseFloat(copyTradeValue.value) / 100
        const targetValue = targetBroker.accountBalance * percentDecimal
        quantity = targetValue / sourceTrade.price
      }

      // Round quantity appropriately
      if (sourceTrade.assetType === "option") {
        quantity = Math.floor(quantity) // Options must be whole contracts
      } else {
        quantity = Math.floor(quantity * 100) / 100 // Round to 2 decimal places
      }

      // Skip if quantity is too small
      if (quantity <= 0) {
        results.push({
          brokerId: targetBroker.id,
          success: false,
          message: "Calculated quantity is too small.",
        })
        continue
      }

      // Create copy trade record
      const copyTrade = await CopyTrade.create(
        {
          sourceBrokerId: sourceTrade.brokerId,
          targetBrokerId: targetBroker.id,
          sourceTradeId: sourceTrade.id,
          status: "pending",
          copyLogic: copyTradeLogic.value,
          copyValue: Number.parseFloat(copyTradeValue.value),
        },
        { transaction },
      )

      // Place order with target broker
      let orderResult

      if (targetBroker.brokerType === "tastytrade") {
        orderResult = await tastytrade.placeOrder(
          targetBroker.accessToken,
          targetBroker.accountId,
          sourceTrade.symbol,
          sourceTrade.side,
          quantity,
          sourceTrade.orderType,
          sourceTrade.price,
          sourceTrade.timeInForce,
          sourceTrade.assetType,
          sourceTrade.optionData,
        )
      } else if (targetBroker.brokerType === "schwab") {
        orderResult = await schwab.placeOrder(
          targetBroker.accessToken,
          targetBroker.accountId,
          sourceTrade.symbol,
          sourceTrade.side,
          quantity,
          sourceTrade.orderType,
          sourceTrade.price,
          sourceTrade.timeInForce,
          sourceTrade.assetType,
          sourceTrade.optionData,
        )
      }

      if (!orderResult.success) {
        // Update copy trade with error
        await copyTrade.update(
          {
            status: "failed",
            errorMessage: orderResult.message,
          },
          { transaction },
        )

        results.push({
          brokerId: targetBroker.id,
          success: false,
          message: orderResult.message,
        })

        // Create notification for failed copy
        await Notification.create(
          {
            userId: sourceTrade.userId,
            type: "trade",
            severity: "error",
            message: `Failed to copy trade for ${sourceTrade.symbol} to ${targetBroker.brokerType} account ${targetBroker.accountId}`,
            details: {
              sourceTradeId: sourceTrade.id,
              targetBrokerId: targetBroker.id,
              symbol: sourceTrade.symbol,
              error: orderResult.message,
            },
          },
          { transaction },
        )

        continue
      }

      // Create target trade record
      const targetTrade = await Trade.create(
        {
          userId: sourceTrade.userId,
          brokerId: targetBroker.id,
          brokerOrderId: orderResult.orderId,
          symbol: sourceTrade.symbol,
          side: sourceTrade.side,
          quantity,
          price: sourceTrade.price,
          orderType: sourceTrade.orderType,
          timeInForce: sourceTrade.timeInForce,
          status: "pending",
          assetType: sourceTrade.assetType,
          optionData: sourceTrade.optionData,
          isManual: false,
          notes: `Copy of trade #${sourceTrade.id}`,
        },
        { transaction },
      )

      // Update copy trade with target trade
      await copyTrade.update(
        {
          targetTradeId: targetTrade.id,
          status: "completed",
        },
        { transaction },
      )

      results.push({
        brokerId: targetBroker.id,
        success: true,
        tradeId: targetTrade.id,
      })

      // Create notification for successful copy
      await Notification.create(
        {
          userId: sourceTrade.userId,
          type: "trade",
          severity: "info",
          message: `Successfully copied trade for ${sourceTrade.symbol} to ${targetBroker.brokerType} account ${targetBroker.accountId}`,
          details: {
            sourceTradeId: sourceTrade.id,
            targetTradeId: targetTrade.id,
            symbol: sourceTrade.symbol,
          },
        },
        { transaction },
      )

      // Log activity
      await ActivityLog.create(
        {
          userId: sourceTrade.userId,
          action: "copyTrade",
          details: {
            sourceTradeId: sourceTrade.id,
            targetTradeId: targetTrade.id,
            symbol: sourceTrade.symbol,
            targetBroker: `${targetBroker.brokerType} ${targetBroker.accountId}`,
          },
        },
        { transaction },
      )
    }

    await transaction.commit()

    return {
      success: true,
      results,
    }
  } catch (error) {
    await transaction.rollback()
    console.error("Execute copy trade error:", error)
    return { success: false, message: "Internal server error." }
  }
}

exports.manualCopyTrade = async (req, res) => {
  try {
    const { tradeId } = req.params

    const result = await this.executeCopyTrade(tradeId, req)

    if (!result.success) {
      return res.status(400).send({ message: result.message })
    }

    return res.status(200).send({
      message: "Trade copied successfully.",
      results: result.results,
    })
  } catch (error) {
    console.error("Manual copy trade error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
