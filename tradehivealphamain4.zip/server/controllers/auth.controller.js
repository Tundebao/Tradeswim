const jwt = require("jsonwebtoken")
const { User, ActivityLog } = require("../models")

exports.login = async (req, res) => {
  try {
    const { username, password } = req.body

    // Find user by username
    const user = await User.findOne({ where: { username } })

    if (!user) {
      return res.status(404).send({ message: "User not found." })
    }

    // Validate password
    const passwordIsValid = await user.validatePassword(password)

    if (!passwordIsValid) {
      return res.status(401).send({ message: "Invalid password." })
    }

    // Generate JWT token
    const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, {
      expiresIn: 86400, // 24 hours
    })

    // Update last login time
    await user.update({ lastLogin: new Date() })

    // Log activity
    await ActivityLog.create({
      userId: user.id,
      action: "login",
      details: { method: "credentials" },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({
      id: user.id,
      username: user.username,
      email: user.email,
      isAdmin: user.isAdmin,
      accessToken: token,
    })
  } catch (error) {
    console.error("Login error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body

    // Check if admin already exists
    const adminExists = await User.findOne({ where: { isAdmin: true } })

    if (adminExists) {
      return res.status(403).send({ message: "Admin account already exists." })
    }

    // Create admin user
    const user = await User.create({
      username,
      email,
      password,
      isAdmin: true,
    })

    // Log activity
    await ActivityLog.create({
      userId: user.id,
      action: "register",
      details: { isAdmin: true },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(201).send({ message: "Admin registered successfully!" })
  } catch (error) {
    console.error("Registration error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.checkAuth = async (req, res) => {
  try {
    const user = await User.findByPk(req.userId, {
      attributes: ["id", "username", "email", "isAdmin", "lastLogin"],
    })

    if (!user) {
      return res.status(404).send({ message: "User not found." })
    }

    return res.status(200).send(user)
  } catch (error) {
    console.error("Check auth error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.changePassword = async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body

    const user = await User.findByPk(req.userId)

    if (!user) {
      return res.status(404).send({ message: "User not found." })
    }

    // Validate current password
    const passwordIsValid = await user.validatePassword(currentPassword)

    if (!passwordIsValid) {
      return res.status(401).send({ message: "Current password is incorrect." })
    }

    // Update password
    await user.update({ password: newPassword })

    // Log activity
    await ActivityLog.create({
      userId: user.id,
      action: "changePassword",
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({ message: "Password changed successfully." })
  } catch (error) {
    console.error("Change password error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
