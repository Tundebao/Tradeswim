const { ActivityLog } = require("../models")
const { Op } = require("sequelize")

exports.getLogs = async (req, res) => {
  try {
    const { action, startDate, endDate, limit, offset } = req.query

    const where = { userId: req.userId }

    if (action) {
      where.action = action
    }

    if (startDate || endDate) {
      where.createdAt = {}

      if (startDate) {
        where.createdAt[Op.gte] = new Date(startDate)
      }

      if (endDate) {
        where.createdAt[Op.lte] = new Date(endDate)
      }
    }

    const logs = await ActivityLog.findAndCountAll({
      where,
      limit: limit ? Number.parseInt(limit) : 100,
      offset: offset ? Number.parseInt(offset) : 0,
      order: [["createdAt", "DESC"]],
    })

    return res.status(200).send({
      count: logs.count,
      logs: logs.rows,
    })
  } catch (error) {
    console.error("Get logs error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getLogActions = async (req, res) => {
  try {
    const actions = await ActivityLog.findAll({
      attributes: ["action"],
      group: ["action"],
    })

    return res.status(200).send(actions.map((a) => a.action))
  } catch (error) {
    console.error("Get log actions error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getAdminLogs = async (req, res) => {
  try {
    const { userId, action, startDate, endDate, limit, offset } = req.query

    const where = {}

    if (userId) {
      where.userId = userId
    }

    if (action) {
      where.action = action
    }

    if (startDate || endDate) {
      where.createdAt = {}

      if (startDate) {
        where.createdAt[Op.gte] = new Date(startDate)
      }

      if (endDate) {
        where.createdAt[Op.lte] = new Date(endDate)
      }
    }

    const logs = await ActivityLog.findAndCountAll({
      where,
      limit: limit ? Number.parseInt(limit) : 100,
      offset: offset ? Number.parseInt(offset) : 0,
      order: [["createdAt", "DESC"]],
    })

    return res.status(200).send({
      count: logs.count,
      logs: logs.rows,
    })
  } catch (error) {
    console.error("Get admin logs error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.clearLogs = async (req, res) => {
  try {
    const { olderThan } = req.body

    if (!olderThan) {
      return res.status(400).send({ message: "olderThan date is required." })
    }

    const date = new Date(olderThan)

    if (isNaN(date.getTime())) {
      return res.status(400).send({ message: "Invalid date format." })
    }

    const result = await ActivityLog.destroy({
      where: {
        createdAt: {
          [Op.lt]: date,
        },
      },
    })

    // Log this action itself
    await ActivityLog.create({
      userId: req.userId,
      action: "clearLogs",
      details: { olderThan, count: result },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    return res.status(200).send({
      message: "Logs cleared successfully.",
      count: result,
    })
  } catch (error) {
    console.error("Clear logs error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
