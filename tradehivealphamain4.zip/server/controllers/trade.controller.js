const { Trade, Broker, Position, Symbol, Notification, Setting, CopyTrade, ActivityLog } = require("../models")
const tastytrade = require("../services/tastytrade.service")
const schwab = require("../services/schwab.service")
const { sequelize } = require("../config/database")

exports.placeOrder = async (req, res) => {
  try {
    const { brokerId, symbol, side, quantity, orderType, price, timeInForce, assetType, optionData } = req.body

    // Validate broker
    const broker = await Broker.findOne({
      where: {
        id: brokerId,
        userId: req.userId,
        isConnected: true,
      },
    })

    if (!broker) {
      return res.status(404).send({ message: "Broker not found or not connected." })
    }

    // Check if symbol is allowed
    const symbolCheck = await Symbol.findOne({ where: { symbol, isAllowed: true } })

    if (!symbolCheck) {
      return res.status(403).send({ message: "Trading this symbol is not allowed." })
    }

    // Check risk settings
    const maxTradeSize = await Setting.findOne({ where: { key: "maxTradeSizePercent" } })

    if (maxTradeSize) {
      const maxSizePercent = Number.parseFloat(maxTradeSize.value)
      const tradeValue = quantity * (price || 0)
      const maxAllowedValue = (broker.accountBalance * maxSizePercent) / 100

      if (tradeValue > maxAllowedValue) {
        // Create notification
        await Notification.create({
          userId: req.userId,
          type: "risk",
          severity: "warning",
          message: `Trade exceeds maximum size of ${maxSizePercent}% of account balance`,
          details: { symbol, side, quantity, orderType, price },
        })

        return res.status(403).send({ message: `Trade exceeds maximum size of ${maxSizePercent}% of account balance.` })
      }
    }

    // Place order with broker
    let orderResult

    if (broker.brokerType === "tastytrade") {
      orderResult = await tastytrade.placeOrder(
        broker.accessToken,
        broker.accountId,
        symbol,
        side,
        quantity,
        orderType,
        price,
        timeInForce,
        assetType,
        optionData,
      )
    } else if (broker.brokerType === "schwab") {
      orderResult = await schwab.placeOrder(
        broker.accessToken,
        broker.accountId,
        symbol,
        side,
        quantity,
        orderType,
        price,
        timeInForce,
        assetType,
        optionData,
      )
    }

    if (!orderResult.success) {
      // Create notification for failed order
      await Notification.create({
        userId: req.userId,
        type: "trade",
        severity: "error",
        message: `Failed to place ${side} order for ${quantity} ${symbol}: ${orderResult.message}`,
        details: { symbol, side, quantity, orderType, price, error: orderResult.message },
      })

      return res.status(400).send({ message: orderResult.message })
    }

    // Create trade record
    const trade = await Trade.create({
      userId: req.userId,
      brokerId: broker.id,
      brokerOrderId: orderResult.orderId,
      symbol,
      side,
      quantity,
      price,
      orderType,
      timeInForce,
      status: "pending",
      assetType,
      optionData,
      isManual: true,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "placeOrder",
      details: { tradeId: trade.id, symbol, side, quantity, orderType },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification for successful order
    await Notification.create({
      userId: req.userId,
      type: "trade",
      severity: "info",
      message: `Successfully placed ${side} order for ${quantity} ${symbol}`,
      details: { symbol, side, quantity, orderType, price, orderId: orderResult.orderId },
    })

    // Check if this is a master account and copy trading is enabled
    if (broker.isMaster) {
      const copyTradingEnabled = await Setting.findOne({ where: { key: "copyTradingEnabled" } })

      if (copyTradingEnabled && copyTradingEnabled.value === "true") {
        // Trigger copy trading
        this.copyTrade(trade.id, req)
      }
    }

    return res.status(200).send({
      message: "Order placed successfully",
      trade: {
        id: trade.id,
        symbol,
        side,
        quantity,
        orderType,
        price,
        status: trade.status,
        brokerOrderId: orderResult.orderId,
      },
    })
  } catch (error) {
    console.error("Place order error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.cancelOrder = async (req, res) => {
  try {
    const { tradeId } = req.params

    const trade = await Trade.findOne({
      where: {
        id: tradeId,
        userId: req.userId,
        status: "pending",
      },
      include: [{ model: Broker }],
    })

    if (!trade) {
      return res.status(404).send({ message: "Trade not found or cannot be cancelled." })
    }

    // Cancel order with broker
    let cancelResult

    if (trade.Broker.brokerType === "tastytrade") {
      cancelResult = await tastytrade.cancelOrder(trade.Broker.accessToken, trade.Broker.accountId, trade.brokerOrderId)
    } else if (trade.Broker.brokerType === "schwab") {
      cancelResult = await schwab.cancelOrder(trade.Broker.accessToken, trade.Broker.accountId, trade.brokerOrderId)
    }

    if (!cancelResult.success) {
      // Create notification for failed cancellation
      await Notification.create({
        userId: req.userId,
        type: "trade",
        severity: "error",
        message: `Failed to cancel order for ${trade.symbol}: ${cancelResult.message}`,
        details: { tradeId: trade.id, symbol: trade.symbol, error: cancelResult.message },
      })

      return res.status(400).send({ message: cancelResult.message })
    }

    // Update trade status
    await trade.update({ status: "cancelled" })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "cancelOrder",
      details: { tradeId: trade.id, symbol: trade.symbol },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification for successful cancellation
    await Notification.create({
      userId: req.userId,
      type: "trade",
      severity: "info",
      message: `Successfully cancelled order for ${trade.symbol}`,
      details: { tradeId: trade.id, symbol: trade.symbol },
    })

    return res.status(200).send({ message: "Order cancelled successfully." })
  } catch (error) {
    console.error("Cancel order error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.updateOrder = async (req, res) => {
  try {
    const { tradeId } = req.params
    const { quantity, price, orderType, timeInForce } = req.body

    const trade = await Trade.findOne({
      where: {
        id: tradeId,
        userId: req.userId,
        status: "pending",
      },
      include: [{ model: Broker }],
    })

    if (!trade) {
      return res.status(404).send({ message: "Trade not found or cannot be updated." })
    }

    // Update order with broker
    let updateResult

    if (trade.Broker.brokerType === "tastytrade") {
      updateResult = await tastytrade.updateOrder(
        trade.Broker.accessToken,
        trade.Broker.accountId,
        trade.brokerOrderId,
        quantity,
        price,
        orderType,
        timeInForce,
      )
    } else if (trade.Broker.brokerType === "schwab") {
      updateResult = await schwab.updateOrder(
        trade.Broker.accessToken,
        trade.Broker.accountId,
        trade.brokerOrderId,
        quantity,
        price,
        orderType,
        timeInForce,
      )
    }

    if (!updateResult.success) {
      // Create notification for failed update
      await Notification.create({
        userId: req.userId,
        type: "trade",
        severity: "error",
        message: `Failed to update order for ${trade.symbol}: ${updateResult.message}`,
        details: { tradeId: trade.id, symbol: trade.symbol, error: updateResult.message },
      })

      return res.status(400).send({ message: updateResult.message })
    }

    // Update trade record
    await trade.update({
      quantity: quantity || trade.quantity,
      price: price || trade.price,
      orderType: orderType || trade.orderType,
      timeInForce: timeInForce || trade.timeInForce,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "updateOrder",
      details: { tradeId: trade.id, symbol: trade.symbol },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification for successful update
    await Notification.create({
      userId: req.userId,
      type: "trade",
      severity: "info",
      message: `Successfully updated order for ${trade.symbol}`,
      details: { tradeId: trade.id, symbol: trade.symbol },
    })

    return res.status(200).send({ message: "Order updated successfully." })
  } catch (error) {
    console.error("Update order error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getTrades = async (req, res) => {
  try {
    const { brokerId, status, symbol, limit, offset } = req.query

    const where = { userId: req.userId }

    if (brokerId) where.brokerId = brokerId
    if (status) where.status = status
    if (symbol) where.symbol = symbol

    const trades = await Trade.findAndCountAll({
      where,
      limit: limit ? Number.parseInt(limit) : 100,
      offset: offset ? Number.parseInt(offset) : 0,
      order: [["createdAt", "DESC"]],
      include: [{ model: Broker, attributes: ["brokerType", "accountId"] }],
    })

    return res.status(200).send({
      count: trades.count,
      trades: trades.rows,
    })
  } catch (error) {
    console.error("Get trades error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.getPositions = async (req, res) => {
  try {
    const { brokerId } = req.query

    const where = { userId: req.userId }

    if (brokerId) where.brokerId = brokerId

    const positions = await Position.findAll({
      where,
      include: [{ model: Broker, attributes: ["brokerType", "accountId"] }],
    })

    return res.status(200).send(positions)
  } catch (error) {
    console.error("Get positions error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.closePosition = async (req, res) => {
  try {
    const { positionId } = req.params

    const position = await Position.findOne({
      where: {
        id: positionId,
        userId: req.userId,
      },
      include: [{ model: Broker }],
    })

    if (!position) {
      return res.status(404).send({ message: "Position not found." })
    }

    // Determine side (opposite of position)
    const side = position.quantity > 0 ? "sell" : "buy"
    const quantity = Math.abs(position.quantity)

    // Place order to close position
    let orderResult

    if (position.Broker.brokerType === "tastytrade") {
      orderResult = await tastytrade.placeOrder(
        position.Broker.accessToken,
        position.Broker.accountId,
        position.symbol,
        side,
        quantity,
        "market",
        null,
        "day",
        position.assetType,
        position.optionData,
      )
    } else if (position.Broker.brokerType === "schwab") {
      orderResult = await schwab.placeOrder(
        position.Broker.accessToken,
        position.Broker.accountId,
        position.symbol,
        side,
        quantity,
        "market",
        null,
        "day",
        position.assetType,
        position.optionData,
      )
    }

    if (!orderResult.success) {
      // Create notification for failed close
      await Notification.create({
        userId: req.userId,
        type: "trade",
        severity: "error",
        message: `Failed to close position for ${position.symbol}: ${orderResult.message}`,
        details: { positionId: position.id, symbol: position.symbol, error: orderResult.message },
      })

      return res.status(400).send({ message: orderResult.message })
    }

    // Create trade record
    const trade = await Trade.create({
      userId: req.userId,
      brokerId: position.brokerId,
      brokerOrderId: orderResult.orderId,
      symbol: position.symbol,
      side,
      quantity,
      orderType: "market",
      timeInForce: "day",
      status: "pending",
      assetType: position.assetType,
      optionData: position.optionData,
      isManual: true,
      notes: `Close position #${position.id}`,
    })

    // Log activity
    await ActivityLog.create({
      userId: req.userId,
      action: "closePosition",
      details: { positionId: position.id, symbol: position.symbol, tradeId: trade.id },
      ipAddress: req.ip,
      userAgent: req.headers["user-agent"],
    })

    // Create notification for successful close
    await Notification.create({
      userId: req.userId,
      type: "trade",
      severity: "info",
      message: `Order placed to close position for ${position.symbol}`,
      details: { positionId: position.id, symbol: position.symbol, tradeId: trade.id },
    })

    return res.status(200).send({
      message: "Order placed to close position",
      trade: {
        id: trade.id,
        symbol: trade.symbol,
        side: trade.side,
        quantity: trade.quantity,
        orderType: trade.orderType,
        status: trade.status,
        brokerOrderId: orderResult.orderId,
      },
    })
  } catch (error) {
    console.error("Close position error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.searchSymbol = async (req, res) => {
  try {
    const { query, brokerType } = req.query

    if (!query) {
      return res.status(400).send({ message: "Search query is required." })
    }

    let searchResult

    if (brokerType === "tastytrade") {
      // Get a connected Tastytrade broker
      const broker = await Broker.findOne({
        where: {
          userId: req.userId,
          brokerType: "tastytrade",
          isConnected: true,
        },
      })

      if (!broker) {
        return res.status(404).send({ message: "No connected Tastytrade broker found." })
      }

      searchResult = await tastytrade.searchSymbol(broker.accessToken, query)
    } else if (brokerType === "schwab") {
      // Get a connected Schwab broker
      const broker = await Broker.findOne({
        where: {
          userId: req.userId,
          brokerType: "schwab",
          isConnected: true,
        },
      })

      if (!broker) {
        return res.status(404).send({ message: "No connected Schwab broker found." })
      }

      searchResult = await schwab.searchSymbol(broker.accessToken, query)
    } else {
      return res.status(400).send({ message: "Invalid broker type." })
    }

    if (!searchResult.success) {
      return res.status(400).send({ message: searchResult.message })
    }

    return res.status(200).send(searchResult.symbols)
  } catch (error) {
    console.error("Search symbol error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.copyTrade = async (sourceTradeId, req) => {
  try {
    const transaction = await sequelize.transaction()

    try {
      // Get source trade
      const sourceTrade = await Trade.findOne({
        where: { id: sourceTradeId },
        include: [{ model: Broker, as: "Broker" }],
        transaction,
      })

      if (!sourceTrade) {
        throw new Error("Source trade not found.")
      }

      // Get copy trading settings
      const copyLogicSetting = await Setting.findOne({
        where: { key: "copyTradeLogic" },
        transaction,
      })

      const copyValueSetting = await Setting.findOne({
        where: { key: "copyTradeValue" },
        transaction,
      })

      if (!copyLogicSetting || !copyValueSetting) {
        throw new Error("Copy trading settings not found.")
      }

      const copyLogic = copyLogicSetting.value
      const copyValue = Number.parseFloat(copyValueSetting.value)

      // Get target brokers (all connected brokers except the source)
      const targetBrokers = await Broker.findAll({
        where: {
          userId: sourceTrade.userId,
          id: { [sequelize.Op.ne]: sourceTrade.brokerId },
          isConnected: true,
        },
        transaction,
      })

      if (targetBrokers.length === 0) {
        throw new Error("No target brokers found.")
      }

      // Process each target broker
      for (const targetBroker of targetBrokers) {
        let quantity = sourceTrade.quantity

        // Calculate quantity based on copy logic
        if (copyLogic === "fixedSize") {
          quantity = copyValue
        } else if (copyLogic === "percentBalance") {
          const percentDecimal = copyValue / 100
          const targetValue = targetBroker.accountBalance * percentDecimal
          quantity = targetValue / sourceTrade.price

          // Round to appropriate precision
          if (sourceTrade.assetType === "option") {
            quantity = Math.floor(quantity) // Options must be whole contracts
          } else {
            quantity = Math.floor(quantity * 100) / 100 // Round to 2 decimal places
          }
        }

        // Skip if quantity is too small
        if (quantity <= 0) {
          continue
        }

        // Create copy trade record
        const copyTrade = await CopyTrade.create(
          {
            sourceBrokerId: sourceTrade.brokerId,
            targetBrokerId: targetBroker.id,
            sourceTradeId: sourceTrade.id,
            status: "pending",
            copyLogic,
            copyValue,
          },
          { transaction },
        )

        // Place order with target broker
        let orderResult

        if (targetBroker.brokerType === "tastytrade") {
          orderResult = await tastytrade.placeOrder(
            targetBroker.accessToken,
            targetBroker.accountId,
            sourceTrade.symbol,
            sourceTrade.side,
            quantity,
            sourceTrade.orderType,
            sourceTrade.price,
            sourceTrade.timeInForce,
            sourceTrade.assetType,
            sourceTrade.optionData,
          )
        } else if (targetBroker.brokerType === "schwab") {
          orderResult = await schwab.placeOrder(
            targetBroker.accessToken,
            targetBroker.accountId,
            sourceTrade.symbol,
            sourceTrade.side,
            quantity,
            sourceTrade.orderType,
            sourceTrade.price,
            sourceTrade.timeInForce,
            sourceTrade.assetType,
            sourceTrade.optionData,
          )
        }

        if (!orderResult.success) {
          // Update copy trade with error
          await copyTrade.update(
            {
              status: "failed",
              errorMessage: orderResult.message,
            },
            { transaction },
          )

          // Create notification for failed copy
          await Notification.create(
            {
              userId: sourceTrade.userId,
              type: "trade",
              severity: "error",
              message: `Failed to copy trade for ${sourceTrade.symbol} to ${targetBroker.brokerType} account ${targetBroker.accountId}`,
              details: {
                sourceTradeId: sourceTrade.id,
                targetBrokerId: targetBroker.id,
                symbol: sourceTrade.symbol,
                error: orderResult.message,
              },
            },
            { transaction },
          )

          continue
        }

        // Create target trade record
        const targetTrade = await Trade.create(
          {
            userId: sourceTrade.userId,
            brokerId: targetBroker.id,
            brokerOrderId: orderResult.orderId,
            symbol: sourceTrade.symbol,
            side: sourceTrade.side,
            quantity,
            price: sourceTrade.price,
            orderType: sourceTrade.orderType,
            timeInForce: sourceTrade.timeInForce,
            status: "pending",
            assetType: sourceTrade.assetType,
            optionData: sourceTrade.optionData,
            isManual: false,
            notes: `Copy of trade #${sourceTrade.id}`,
          },
          { transaction },
        )

        // Update copy trade with target trade
        await copyTrade.update(
          {
            targetTradeId: targetTrade.id,
            status: "completed",
          },
          { transaction },
        )

        // Create notification for successful copy
        await Notification.create(
          {
            userId: sourceTrade.userId,
            type: "trade",
            severity: "info",
            message: `Successfully copied trade for ${sourceTrade.symbol} to ${targetBroker.brokerType} account ${targetBroker.accountId}`,
            details: {
              sourceTradeId: sourceTrade.id,
              targetTradeId: targetTrade.id,
              symbol: sourceTrade.symbol,
            },
          },
          { transaction },
        )

        // Log activity
        await ActivityLog.create(
          {
            userId: sourceTrade.userId,
            action: "copyTrade",
            details: {
              sourceTradeId: sourceTrade.id,
              targetTradeId: targetTrade.id,
              symbol: sourceTrade.symbol,
              targetBroker: `${targetBroker.brokerType} ${targetBroker.accountId}`,
            },
          },
          { transaction },
        )
      }

      await transaction.commit()
      return { success: true }
    } catch (error) {
      await transaction.rollback()
      console.error("Copy trade error:", error)

      // Create notification for copy trade error
      await Notification.create({
        userId: req.userId,
        type: "trade",
        severity: "error",
        message: `Error in copy trading process: ${error.message}`,
        details: { sourceTradeId, error: error.message },
      })

      return { success: false, message: error.message }
    }
  } catch (error) {
    console.error("Copy trade outer error:", error)
    return { success: false, message: "Internal server error." }
  }
}

exports.manualCopyTrade = async (req, res) => {
  try {
    const { tradeId } = req.params

    const result = await this.copyTrade(tradeId, req)

    if (!result.success) {
      return res.status(400).send({ message: result.message })
    }

    return res.status(200).send({ message: "Trade copied successfully." })
  } catch (error) {
    console.error("Manual copy trade error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}

exports.syncPositions = async (req, res) => {
  try {
    const { brokerId } = req.params

    const broker = await Broker.findOne({
      where: {
        id: brokerId,
        userId: req.userId,
        isConnected: true,
      },
    })

    if (!broker) {
      return res.status(404).send({ message: "Broker not found or not connected." })
    }

    let positionsResult

    if (broker.brokerType === "tastytrade") {
      positionsResult = await tastytrade.getPositions(broker.accessToken, broker.accountId)
    } else if (broker.brokerType === "schwab") {
      positionsResult = await schwab.getPositions(broker.accessToken, broker.accountId)
    }

    if (!positionsResult.success) {
      return res.status(400).send({ message: positionsResult.message })
    }

    // Update positions in database
    const transaction = await sequelize.transaction()

    try {
      // Delete existing positions for this broker
      await Position.destroy({
        where: {
          userId: req.userId,
          brokerId: broker.id,
        },
        transaction,
      })

      // Create new positions
      for (const pos of positionsResult.positions) {
        await Position.create(
          {
            userId: req.userId,
            brokerId: broker.id,
            symbol: pos.symbol,
            quantity: pos.quantity,
            averagePrice: pos.averagePrice,
            currentPrice: pos.currentPrice,
            marketValue: pos.marketValue,
            unrealizedPnL: pos.unrealizedPnL,
            unrealizedPnLPercent: pos.unrealizedPnLPercent,
            assetType: pos.assetType,
            optionData: pos.optionData,
            lastUpdated: new Date(),
          },
          { transaction },
        )
      }

      // Update broker last sync time
      await broker.update(
        {
          lastSyncTime: new Date(),
        },
        { transaction },
      )

      await transaction.commit()

      // Broadcast position update via WebSocket
      global.broadcastUpdate({
        type: "positions",
        brokerId: broker.id,
        accountId: broker.accountId,
        positions: positionsResult.positions,
      })

      return res.status(200).send({
        message: "Positions synced successfully",
        positions: positionsResult.positions,
      })
    } catch (error) {
      await transaction.rollback()
      console.error("Sync positions transaction error:", error)
      return res.status(500).send({ message: "Internal server error." })
    }
  } catch (error) {
    console.error("Sync positions error:", error)
    return res.status(500).send({ message: "Internal server error." })
  }
}
