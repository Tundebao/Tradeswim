const axios = require("axios")

const BASE_URL = "https://api.tastytrade.com"
const CERT_URL = "https://cert.tastytrade.com"

// Authenticate with Tastytrade
exports.authenticate = async (username, password) => {
  try {
    const response = await axios.post(`${CERT_URL}/sessions`, {
      login: username,
      password: password,
    })

    if (response.status === 201) {
      return {
        success: true,
        session_token: response.data.session_token,
      }
    } else {
      return {
        success: false,
        message: "Authentication failed",
      }
    }
  } catch (error) {
    console.error("Tastytrade authentication error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Authentication failed",
    }
  }
}

// Get account information
exports.getAccountInfo = async (sessionToken) => {
  try {
    const response = await axios.get(`${BASE_URL}/customers/me/accounts`, {
      headers: {
        Authorization: sessionToken,
      },
    })

    if (response.status === 200 && response.data.items && response.data.items.length > 0) {
      const account = response.data.items[0]

      // Get account balance
      const balanceResponse = await axios.get(`${BASE_URL}/accounts/${account.account_number}/balances`, {
        headers: {
          Authorization: sessionToken,
        },
      })

      if (balanceResponse.status === 200) {
        return {
          success: true,
          account: {
            account_number: account.account_number,
            nickname: account.nickname,
            account_type: account.account_type,
            equity: balanceResponse.data.equity,
            buying_power: balanceResponse.data.buying_power,
          },
        }
      }
    }

    return {
      success: false,
      message: "Failed to retrieve account information",
    }
  } catch (error) {
    console.error("Tastytrade get account info error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Failed to retrieve account information",
    }
  }
}

// Place order
exports.placeOrder = async (
  sessionToken,
  accountId,
  symbol,
  side,
  quantity,
  orderType,
  price,
  timeInForce,
  assetType,
  optionData,
) => {
  try {
    const endpoint = `${BASE_URL}/accounts/${accountId}/orders`
    const orderData = {
      account_number: accountId,
      source: "API",
      time_in_force: timeInForce,
      price_effect: side === "buy" ? "Debit" : "Credit",
      order_type: orderType,
    }

    if (orderType === "limit" || orderType === "stop") {
      orderData.price = price
    }

    if (assetType === "option") {
      // Handle option order
      orderData.legs = [
        {
          instrument_type: "Equity Option",
          symbol: symbol,
          quantity: quantity,
          side: side === "buy" ? "Buy to Open" : "Sell to Open",
          expiration_date: optionData.expirationDate,
          strike: optionData.strike,
          option_type: optionData.optionType,
        },
      ]
    } else {
      // Handle stock/ETF order
      orderData.legs = [
        {
          instrument_type: "Equity",
          symbol: symbol,
          quantity: quantity,
          side: side === "buy" ? "Buy to Open" : "Sell to Open",
        },
      ]
    }

    const response = await axios.post(endpoint, orderData, {
      headers: {
        Authorization: sessionToken,
        "Content-Type": "application/json",
      },
    })

    if (response.status === 201) {
      return {
        success: true,
        orderId: response.data.order_id,
      }
    } else {
      return {
        success: false,
        message: "Failed to place order",
      }
    }
  } catch (error) {
    console.error("Tastytrade place order error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Failed to place order",
    }
  }
}

// Cancel order
exports.cancelOrder = async (sessionToken, accountId, orderId) => {
  try {
    const response = await axios.delete(`${BASE_URL}/accounts/${accountId}/orders/${orderId}`, {
      headers: {
        Authorization: sessionToken,
      },
    })

    if (response.status === 204) {
      return {
        success: true,
      }
    } else {
      return {
        success: false,
        message: "Failed to cancel order",
      }
    }
  } catch (error) {
    console.error("Tastytrade cancel order error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Failed to cancel order",
    }
  }
}

// Update order
exports.updateOrder = async (sessionToken, accountId, orderId, quantity, price, orderType, timeInForce) => {
  try {
    const orderData = {
      account_number: accountId,
      order_type: orderType,
      time_in_force: timeInForce,
    }

    if (price) {
      orderData.price = price
    }

    if (quantity) {
      // Need to get current order to update legs
      const orderResponse = await axios.get(`${BASE_URL}/accounts/${accountId}/orders/${orderId}`, {
        headers: {
          Authorization: sessionToken,
        },
      })

      if (orderResponse.status === 200) {
        const currentOrder = orderResponse.data
        orderData.legs = currentOrder.legs.map((leg) => ({
          ...leg,
          quantity: quantity,
        }))
      }
    }

    const response = await axios.put(`${BASE_URL}/accounts/${accountId}/orders/${orderId}`, orderData, {
      headers: {
        Authorization: sessionToken,
        "Content-Type": "application/json",
      },
    })

    if (response.status === 200) {
      return {
        success: true,
        orderId: response.data.order_id,
      }
    } else {
      return {
        success: false,
        message: "Failed to update order",
      }
    }
  } catch (error) {
    console.error("Tastytrade update order error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Failed to update order",
    }
  }
}

// Get positions
exports.getPositions = async (sessionToken, accountId) => {
  try {
    const response = await axios.get(`${BASE_URL}/accounts/${accountId}/positions`, {
      headers: {
        Authorization: sessionToken,
      },
    })

    if (response.status === 200) {
      const positions = response.data.items.map((pos) => {
        let assetType = "stock"
        let optionData = null

        if (pos.instrument_type === "Equity Option") {
          assetType = "option"
          optionData = {
            expirationDate: pos.expiration_date,
            strike: pos.strike_price,
            optionType: pos.option_type,
          }
        } else if (pos.symbol.includes("-")) {
          assetType = "etf"
        }

        return {
          symbol: pos.symbol,
          quantity: pos.quantity,
          averagePrice: pos.average_open_price,
          currentPrice: pos.mark_price,
          marketValue: pos.mark_value,
          unrealizedPnL: pos.unrealized_gain_loss,
          unrealizedPnLPercent: (pos.unrealized_gain_loss / (pos.average_open_price * Math.abs(pos.quantity))) * 100,
          assetType,
          optionData,
        }
      })

      return {
        success: true,
        positions,
      }
    } else {
      return {
        success: false,
        message: "Failed to retrieve positions",
      }
    }
  } catch (error) {
    console.error("Tastytrade get positions error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Failed to retrieve positions",
    }
  }
}

// Search symbol
exports.searchSymbol = async (sessionToken, query) => {
  try {
    const response = await axios.get(`${BASE_URL}/instruments/search?query=${encodeURIComponent(query)}`, {
      headers: {
        Authorization: sessionToken,
      },
    })

    if (response.status === 200) {
      const symbols = response.data.data.items.map((item) => {
        let type = "stock"

        if (item.instrument_type === "Equity Option") {
          type = "option"
        } else if (item.symbol.includes("-")) {
          type = "etf"
        }

        return {
          symbol: item.symbol,
          name: item.description,
          type,
        }
      })

      return {
        success: true,
        symbols,
      }
    } else {
      return {
        success: false,
        message: "Failed to search symbols",
      }
    }
  } catch (error) {
    console.error("Tastytrade search symbol error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error || "Failed to search symbols",
    }
  }
}
