const cron = require("node-cron")
const { Broker, Position, Trade, Setting, Notification, ActivityLog } = require("../models")
const tastytrade = require("./tastytrade.service")
const schwab = require("./schwab.service")
const { Op } = require("sequelize")

// Initialize schedulers
const initSchedulers = () => {
  // Sync positions every 5 minutes during market hours
  cron.schedule("*/5 9-16 * * 1-5", async () => {
    try {
      console.log("Running scheduled position sync")
      await syncAllPositions()
    } catch (error) {
      console.error("Scheduled position sync error:", error)
    }
  })

  // Check for expired options daily at 8 AM
  cron.schedule("0 8 * * 1-5", async () => {
    try {
      console.log("Running expired options check")
      await checkExpiredOptions()
    } catch (error) {
      console.error("Expired options check error:", error)
    }
  })

  // Clean up old logs weekly on Sunday at 1 AM
  cron.schedule("0 1 * * 0", async () => {
    try {
      console.log("Running log cleanup")
      await cleanupOldLogs()
    } catch (error) {
      console.error("Log cleanup error:", error)
    }
  })
}

// Sync positions for all connected brokers
const syncAllPositions = async () => {
  try {
    // Get all connected brokers
    const brokers = await Broker.findAll({
      where: { isConnected: true },
    })

    for (const broker of brokers) {
      try {
        let positionsResult

        if (broker.brokerType === "tastytrade") {
          positionsResult = await tastytrade.getPositions(broker.accessToken, broker.accountId)
        } else if (broker.brokerType === "schwab") {
          positionsResult = await schwab.getPositions(broker.accessToken, broker.accountId)
        }

        if (positionsResult.success) {
          // Update positions in database
          await Position.destroy({
            where: {
              userId: broker.userId,
              brokerId: broker.id,
            },
          })

          for (const pos of positionsResult.positions) {
            await Position.create({
              userId: broker.userId,
              brokerId: broker.id,
              symbol: pos.symbol,
              quantity: pos.quantity,
              averagePrice: pos.averagePrice,
              currentPrice: pos.currentPrice,
              marketValue: pos.marketValue,
              unrealizedPnL: pos.unrealizedPnL,
              unrealizedPnLPercent: pos.unrealizedPnLPercent,
              assetType: pos.assetType,
              optionData: pos.optionData,
              lastUpdated: new Date(),
            })
          }

          // Update broker last sync time
          await broker.update({
            lastSyncTime: new Date(),
          })

          // Broadcast position update via WebSocket
          global.broadcastUpdate({
            type: "positions",
            userId: broker.userId,
            brokerId: broker.id,
            accountId: broker.accountId,
            positions: positionsResult.positions,
          })
        } else {
          console.error(`Failed to sync positions for broker ${broker.id}:`, positionsResult.message)
        }
      } catch (error) {
        console.error(`Error syncing positions for broker ${broker.id}:`, error)
      }
    }
  } catch (error) {
    console.error("Sync all positions error:", error)
  }
}

// Check for expired options
const checkExpiredOptions = async () => {
  try {
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    // Get all option positions
    const optionPositions = await Position.findAll({
      where: {
        assetType: "option",
      },
      include: [{ model: Broker }],
    })

    for (const position of optionPositions) {
      try {
        if (!position.optionData || !position.optionData.expirationDate) {
          continue
        }

        const expirationDate = new Date(position.optionData.expirationDate)
        expirationDate.setHours(0, 0, 0, 0)

        // Check if option expires today
        if (expirationDate.getTime() === today.getTime()) {
          // Create notification
          await Notification.create({
            userId: position.userId,
            type: "position",
            severity: "warning",
            message: `Option ${position.symbol} expires today`,
            details: {
              symbol: position.symbol,
              expirationDate: position.optionData.expirationDate,
              strike: position.optionData.strike,
              optionType: position.optionData.optionType,
            },
          })

          // Broadcast notification via WebSocket
          global.broadcastUpdate({
            type: "notification",
            userId: position.userId,
            notification: {
              type: "position",
              severity: "warning",
              message: `Option ${position.symbol} expires today`,
            },
          })
        }
      } catch (error) {
        console.error(`Error checking option expiration for position ${position.id}:`, error)
      }
    }
  } catch (error) {
    console.error("Check expired options error:", error)
  }
}

// Clean up old logs
const cleanupOldLogs = async () => {
  try {
    // Get log retention setting
    const logRetention = await Setting.findOne({ where: { key: "logRetentionDays" } })
    const retentionDays = logRetention ? Number.parseInt(logRetention.value) : 30

    // Calculate cutoff date
    const cutoffDate = new Date()
    cutoffDate.setDate(cutoffDate.getDate() - retentionDays)

    // Delete old logs
    const result = await ActivityLog.destroy({
      where: {
        createdAt: {
          [Op.lt]: cutoffDate,
        },
      },
    })

    console.log(`Cleaned up ${result} old logs older than ${retentionDays} days`)
  } catch (error) {
    console.error("Cleanup old logs error:", error)
  }
}

module.exports = { initSchedulers, syncAllPositions }
