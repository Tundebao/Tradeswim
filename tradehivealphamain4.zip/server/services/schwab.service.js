const axios = require("axios")
const querystring = require("querystring")

// Schwab API configuration
const SCHWAB_API_BASE = "https://api.schwabapi.com/v1"
const SCHWAB_AUTH_URL = "https://api.schwabapi.com/oauth2/authorize"
const SCHWAB_TOKEN_URL = "https://api.schwabapi.com/oauth2/token"
const SCHWAB_REVOKE_URL = "https://api.schwabapi.com/oauth2/revoke"

// Client credentials (should be stored securely in environment variables)
const CLIENT_ID = process.env.SCHWAB_CLIENT_ID
const CLIENT_SECRET = process.env.SCHWAB_CLIENT_SECRET
const REDIRECT_URI = process.env.SCHWAB_REDIRECT_URI

// Get authorization URL for OAuth flow
exports.getAuthorizationUrl = () => {
  const params = {
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: "code",
    scope: "accounts trading",
    state: Date.now().toString(), // Use a more secure state in production
  }

  return `${SCHWAB_AUTH_URL}?${querystring.stringify(params)}`
}

// Exchange authorization code for tokens
exports.exchangeCodeForTokens = async (code) => {
  try {
    const params = {
      grant_type: "authorization_code",
      code,
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uri: REDIRECT_URI,
    }

    const response = await axios.post(SCHWAB_TOKEN_URL, querystring.stringify(params), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })

    if (response.status === 200) {
      return {
        success: true,
        access_token: response.data.access_token,
        refresh_token: response.data.refresh_token,
        expires_in: response.data.expires_in,
      }
    } else {
      return {
        success: false,
        message: "Failed to exchange code for tokens",
      }
    }
  } catch (error) {
    console.error("Schwab token exchange error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error_description || "Failed to exchange code for tokens",
    }
  }
}

// Refresh access token
exports.refreshToken = async (refreshToken) => {
  try {
    const params = {
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
    }

    const response = await axios.post(SCHWAB_TOKEN_URL, querystring.stringify(params), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })

    if (response.status === 200) {
      return {
        success: true,
        access_token: response.data.access_token,
        refresh_token: response.data.refresh_token,
        expires_in: response.data.expires_in,
      }
    } else {
      return {
        success: false,
        message: "Failed to refresh token",
      }
    }
  } catch (error) {
    console.error("Schwab token refresh error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error_description || "Failed to refresh token",
    }
  }
}

// Revoke token
exports.revokeToken = async (token) => {
  try {
    const params = {
      token,
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
    }

    const response = await axios.post(SCHWAB_REVOKE_URL, querystring.stringify(params), {
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })

    if (response.status === 200) {
      return {
        success: true,
      }
    } else {
      return {
        success: false,
        message: "Failed to revoke token",
      }
    }
  } catch (error) {
    console.error("Schwab token revocation error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.error_description || "Failed to revoke token",
    }
  }
}

// Get account information
exports.getAccountInfo = async (accessToken) => {
  try {
    const response = await axios.get(`${SCHWAB_API_BASE}/accounts`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response.status === 200) {
      const accounts = response.data.accounts.map((acc) => ({
        accountId: acc.accountId,
        accountName: acc.accountName,
        accountType: acc.accountType,
        equity: acc.equity,
        buyingPower: acc.buyingPower,
        marginAvailable: acc.marginAvailable,
      }))

      return {
        success: true,
        accounts,
      }
    } else {
      return {
        success: false,
        message: "Failed to retrieve account information",
      }
    }
  } catch (error) {
    console.error("Schwab get account info error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.message || "Failed to retrieve account information",
    }
  }
}

// Place order
exports.placeOrder = async (
  accessToken,
  accountId,
  symbol,
  side,
  quantity,
  orderType,
  price,
  timeInForce,
  assetType,
  optionData,
) => {
  try {
    const orderData = {
      accountId,
      symbol,
      side: side.toUpperCase(),
      quantity,
      orderType: orderType.toUpperCase(),
      timeInForce: timeInForce.toUpperCase(),
    }

    if (orderType === "limit" || orderType === "stop") {
      orderData.price = price
    }

    if (assetType === "option") {
      orderData.assetType = "OPTION"
      orderData.optionData = {
        expirationDate: optionData.expirationDate,
        strike: optionData.strike,
        optionType: optionData.optionType.toUpperCase(),
      }
    } else {
      orderData.assetType = "EQUITY"
    }

    const response = await axios.post(`${SCHWAB_API_BASE}/orders`, orderData, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    })

    if (response.status === 201) {
      return {
        success: true,
        orderId: response.data.orderId,
      }
    } else {
      return {
        success: false,
        message: "Failed to place order",
      }
    }
  } catch (error) {
    console.error("Schwab place order error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.message || "Failed to place order",
    }
  }
}

// Cancel order
exports.cancelOrder = async (accessToken, accountId, orderId) => {
  try {
    const response = await axios.delete(`${SCHWAB_API_BASE}/accounts/${accountId}/orders/${orderId}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response.status === 204) {
      return {
        success: true,
      }
    } else {
      return {
        success: false,
        message: "Failed to cancel order",
      }
    }
  } catch (error) {
    console.error("Schwab cancel order error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.message || "Failed to cancel order",
    }
  }
}

// Update order
exports.updateOrder = async (accessToken, accountId, orderId, quantity, price, orderType, timeInForce) => {
  try {
    // First get the current order
    const orderResponse = await axios.get(`${SCHWAB_API_BASE}/accounts/${accountId}/orders/${orderId}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (orderResponse.status !== 200) {
      return {
        success: false,
        message: "Failed to retrieve order details",
      }
    }

    const currentOrder = orderResponse.data

    // Prepare update data
    const updateData = {
      accountId,
      symbol: currentOrder.symbol,
      side: currentOrder.side,
      quantity: quantity || currentOrder.quantity,
      orderType: orderType || currentOrder.orderType,
      timeInForce: timeInForce || currentOrder.timeInForce,
      assetType: currentOrder.assetType,
    }

    if (price) {
      updateData.price = price
    } else if (currentOrder.price) {
      updateData.price = currentOrder.price
    }

    if (currentOrder.assetType === "OPTION") {
      updateData.optionData = currentOrder.optionData
    }

    const response = await axios.put(`${SCHWAB_API_BASE}/accounts/${accountId}/orders/${orderId}`, updateData, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
        "Content-Type": "application/json",
      },
    })

    if (response.status === 200) {
      return {
        success: true,
        orderId: response.data.orderId,
      }
    } else {
      return {
        success: false,
        message: "Failed to update order",
      }
    }
  } catch (error) {
    console.error("Schwab update order error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.message || "Failed to update order",
    }
  }
}

// Get positions
exports.getPositions = async (accessToken, accountId) => {
  try {
    const response = await axios.get(`${SCHWAB_API_BASE}/accounts/${accountId}/positions`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response.status === 200) {
      const positions = response.data.positions.map((pos) => {
        let assetType = "stock"
        let optionData = null

        if (pos.assetType === "OPTION") {
          assetType = "option"
          optionData = {
            expirationDate: pos.optionData.expirationDate,
            strike: pos.optionData.strike,
            optionType: pos.optionData.optionType.toLowerCase(),
          }
        } else if (pos.assetType === "ETF") {
          assetType = "etf"
        }

        return {
          symbol: pos.symbol,
          quantity: pos.quantity,
          averagePrice: pos.averagePrice,
          currentPrice: pos.currentPrice,
          marketValue: pos.marketValue,
          unrealizedPnL: pos.unrealizedPnL,
          unrealizedPnLPercent: pos.unrealizedPnLPercent,
          assetType,
          optionData,
        }
      })

      return {
        success: true,
        positions,
      }
    } else {
      return {
        success: false,
        message: "Failed to retrieve positions",
      }
    }
  } catch (error) {
    console.error("Schwab get positions error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.message || "Failed to retrieve positions",
    }
  }
}

// Search symbol
exports.searchSymbol = async (accessToken, query) => {
  try {
    const response = await axios.get(`${SCHWAB_API_BASE}/instruments/search?query=${encodeURIComponent(query)}`, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    })

    if (response.status === 200) {
      const symbols = response.data.instruments.map((item) => {
        let type = "stock"

        if (item.assetType === "OPTION") {
          type = "option"
        } else if (item.assetType === "ETF") {
          type = "etf"
        }

        return {
          symbol: item.symbol,
          name: item.name,
          type,
        }
      })

      return {
        success: true,
        symbols,
      }
    } else {
      return {
        success: false,
        message: "Failed to search symbols",
      }
    }
  } catch (error) {
    console.error("Schwab search symbol error:", error.response?.data || error.message)
    return {
      success: false,
      message: error.response?.data?.message || "Failed to search symbols",
    }
  }
}
