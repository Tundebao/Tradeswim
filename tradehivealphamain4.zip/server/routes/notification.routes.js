const express = require("express")
const notificationController = require("../controllers/notification.controller")

const router = express.Router()

router.get("/", notificationController.getNotifications)
router.put("/:notificationId/read", notificationController.markAsRead)
router.put("/read-all", notificationController.markAllAsRead)
router.delete("/:notificationId", notificationController.deleteNotification)
router.delete("/", notificationController.clearAllNotifications)

module.exports = router
