const express = require("express")
const { verifyToken } = require("../middleware/auth.middleware")
const riskController = require("../controllers/risk.controller")

const router = express.Router()

// Get risk settings
router.get("/settings", verifyToken, riskController.getRiskSettings)

// Update risk settings
router.put("/settings", verifyToken, riskController.updateRiskSettings)

// Get daily risk report
router.get("/report", verifyToken, riskController.getDailyRiskReport)

module.exports = router
