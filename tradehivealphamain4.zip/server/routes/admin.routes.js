const express = require("express")
const { isAdmin } = require("../middleware/auth.middleware")
const adminController = require("../controllers/admin.controller")

const router = express.Router()

// Apply admin middleware to all routes
router.use(isAdmin)

// Settings routes
router.get("/settings", adminController.getSettings)
router.post("/settings", adminController.createSetting)
router.put("/settings/:key", adminController.updateSetting)
router.delete("/settings/:key", adminController.deleteSetting)
router.post("/settings/initialize", adminController.initializeDefaultSettings)

// Symbol routes
router.get("/symbols", adminController.getSymbols)
router.post("/symbols", adminController.createSymbol)
router.put("/symbols/:symbolId", adminController.updateSymbol)
router.delete("/symbols/:symbolId", adminController.deleteSymbol)

// Activity logs
router.get("/logs", adminController.getActivityLogs)

// Dashboard stats
router.get("/dashboard", adminController.getDashboardStats)

module.exports = router
