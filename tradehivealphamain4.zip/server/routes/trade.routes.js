const express = require("express")
const tradeController = require("../controllers/trade.controller")

const router = express.Router()

// Order management
router.post("/order", tradeController.placeOrder)
router.post("/order/:tradeId/cancel", tradeController.cancelOrder)
router.put("/order/:tradeId", tradeController.updateOrder)
router.get("/", tradeController.getTrades)

// Position management
router.get("/positions", tradeController.getPositions)
router.post("/positions/:positionId/close", tradeController.closePosition)
router.post("/positions/:brokerId/sync", tradeController.syncPositions)

// Symbol search
router.get("/symbol/search", tradeController.searchSymbol)

// Copy trading
router.post("/copy/:tradeId", tradeController.manualCopyTrade)

module.exports = router
