const express = require("express")
const { verifyToken } = require("../middleware/auth.middleware")
const copyTradeController = require("../controllers/copyTrade.controller")

const router = express.Router()

// Get copy trading status
router.get("/status", verifyToken, copyTradeController.getCopyTradingStatus)

// Toggle copy trading
router.post("/toggle", verifyToken, copyTradeController.toggleCopyTrading)

// Get copy trades
router.get("/", verifyToken, copyTradeController.getCopyTrades)

// Manually copy a trade
router.post("/:tradeId", verifyToken, copyTradeController.manualCopyTrade)

module.exports = router
