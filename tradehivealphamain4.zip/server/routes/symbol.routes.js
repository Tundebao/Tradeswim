const express = require("express")
const { verifyToken, isAdmin } = require("../middleware/auth.middleware")
const symbolController = require("../controllers/symbol.controller")

const router = express.Router()

// Get all symbols
router.get("/", verifyToken, symbolController.getSymbols)

// Get symbol by symbol
router.get("/:symbol", verifyToken, symbolController.getSymbol)

// Create symbol (admin only)
router.post("/", [verifyToken, isAdmin], symbolController.createSymbol)

// Update symbol (admin only)
router.put("/:symbol", [verifyToken, isAdmin], symbolController.updateSymbol)

// Delete symbol (admin only)
router.delete("/:symbol", [verifyToken, isAdmin], symbolController.deleteSymbol)

// Bulk update symbols (admin only)
router.post("/bulk", [verifyToken, isAdmin], symbolController.bulkUpdateSymbols)

module.exports = router
