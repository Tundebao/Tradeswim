const express = require("express")
const { verifyToken } = require("../middleware/auth.middleware")
const authController = require("../controllers/auth.controller")

const router = express.Router()

// Public routes
router.post("/login", authController.login)
router.post("/register", authController.register)

// Protected routes
router.get("/check", verifyToken, authController.checkAuth)
router.post("/change-password", verifyToken, authController.changePassword)

module.exports = router
