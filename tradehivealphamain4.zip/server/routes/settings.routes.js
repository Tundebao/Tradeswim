const express = require("express")
const { verifyToken, isAdmin } = require("../middleware/auth.middleware")
const settingsController = require("../controllers/settings.controller")

const router = express.Router()

// Get all settings
router.get("/", verifyToken, settingsController.getSettings)

// Update settings (admin only)
router.put("/", [verifyToken, isAdmin], settingsController.updateSettings)

// Copy trading settings
router.get("/copy-trading", verifyToken, settingsController.getCopyTradingSettings)
router.put("/copy-trading", [verifyToken, isAdmin], settingsController.updateCopyTradingSettings)

// Symbol settings
router.get("/symbols", verifyToken, settingsController.getSymbolSettings)
router.put("/symbols", [verifyToken, isAdmin], settingsController.updateSymbolSettings)

module.exports = router
