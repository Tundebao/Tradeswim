const express = require("express")
const brokerController = require("../controllers/broker.controller")

const router = express.Router()

// Tastytrade routes
router.post("/tastytrade/connect", brokerController.connectTastytrade)

// Schwab routes
router.get("/schwab/auth", brokerController.initiateSchwabAuth)
router.post("/schwab/callback", brokerController.completeSchwabAuth)

// General broker routes
router.get("/", brokerController.getBrokers)
router.post("/:brokerId/disconnect", brokerController.disconnectBroker)
router.post("/:brokerId/set-master", brokerController.setMasterBroker)
router.post("/:brokerId/refresh", brokerController.refreshBrokerData)

module.exports = router
