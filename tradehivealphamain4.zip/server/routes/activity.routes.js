const express = require("express")
const { verifyToken, isAdmin } = require("../middleware/auth.middleware")
const activityController = require("../controllers/activity.controller")

const router = express.Router()

// Get user's own logs
router.get("/", verifyToken, activityController.getLogs)

// Get available log actions
router.get("/actions", verifyToken, activityController.getLogActions)

// Admin routes
router.get("/admin", [verifyToken, isAdmin], activityController.getAdminLogs)
router.post("/clear", [verifyToken, isAdmin], activityController.clearLogs)

module.exports = router
